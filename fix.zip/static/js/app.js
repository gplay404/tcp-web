async function postJson(url, data = {}) {
    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    });
    const payload = await response.json();
    if (!response.ok) {
        throw new Error(payload.error || "Request failed");
    }
    return payload;
}

function setLoading(button, isLoading) {
    if (!button) {
        return;
    }
    if (isLoading) {
        if (!button.dataset.originalLabel) {
            button.dataset.originalLabel = button.innerHTML;
        }
        button.disabled = true;
        button.innerHTML = '<span class="inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-r-transparent"></span><span>Loading...</span>';
        button.style.opacity = '0.7';
        button.style.pointerEvents = 'none';
    } else {
        button.disabled = false;
        if (button.dataset.originalLabel) {
            button.innerHTML = button.dataset.originalLabel;
        }
        button.style.opacity = '1';
        button.style.pointerEvents = 'auto';
    }
}

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) {
        el.textContent = value;
    }
}

let accountInfoCaptureInterval = null;
let accountInfoCaptureAttempts = 0;
const MAX_ACCOUNT_INFO_ATTEMPTS = 12;

function setBioText(value) {
    const text = value || "No bio found.";
    const small = document.getElementById("account-bio");
    if (small) {
        small.textContent = text;
    }
}

function setBotLogs(lines) {
    const output = document.getElementById("bot-logs");
    if (!output) {
        return;
    }
    if (!lines || !lines.length) {
        output.textContent = "No logs yet.";
        return;
    }
    output.textContent = lines.join("\n");
    output.scrollTop = output.scrollHeight;
}

function setConsoleState(text) {
    const el = document.getElementById("console-state");
    if (el) {
        el.textContent = text;
    }
}

function setToolResponseCard(result, fallbackTitle = "Action Result") {
    const title = document.getElementById("tool-response-title");
    const message = document.getElementById("tool-response-message");
    if (title) {
        title.textContent = result?.action ? result.action.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()) : fallbackTitle;
    }
    if (message) {
        message.textContent = result?.message || "Action completed successfully.";
    }
}

function playerCardHtml(player) {
    const bio = player.bio || "No bio found.";
    return `
        <div class="rounded-2xl border border-white/10 bg-slate-950/60 p-4 shadow-lg transition hover:-translate-y-0.5 hover:border-cyan-400/20">
            <p class="text-xs uppercase tracking-[0.25em] text-slate-500">Player</p>
            <p class="mt-2 text-lg font-semibold text-white">${player.name || "Unknown"}</p>
            <div class="mt-4 grid gap-2 text-sm text-slate-300">
                <div class="flex items-center justify-between"><span class="text-slate-500">UID</span><span>${player.uid || "Unknown"}</span></div>
                <div class="flex items-center justify-between"><span class="text-slate-500">Level</span><span>${player.level || "Unknown"}</span></div>
                <div class="flex items-center justify-between"><span class="text-slate-500">Region</span><span>${player.region || "Unknown"}</span></div>
            </div>
            <div class="mt-4">
                <div class="mb-2 flex items-center justify-between gap-3">
                    <p class="text-xs uppercase tracking-[0.25em] text-slate-500">Bio</p>
                    <button type="button" class="copy-player-bio inline-flex items-center justify-center rounded-xl border border-cyan-400/20 bg-cyan-400/10 px-3 py-2 text-xs font-medium text-cyan-200 transition hover:border-cyan-300/30 hover:bg-cyan-400/15" data-bio="${escapeHtmlAttribute(bio)}">
                        Copy Bio
                    </button>
                </div>
                <div class="scrollbar-slim max-h-28 overflow-auto rounded-2xl border border-white/10 bg-black/30 px-3 py-3 text-sm leading-6 text-slate-300">${escapeHtml(bio)}</div>
            </div>
        </div>
    `;
}

function dedupePlayersByUid(players) {
    const seen = new Set();
    return (Array.isArray(players) ? players : []).filter((player) => {
        const uid = String(player?.uid || "").trim();
        if (!uid) {
            return true;
        }
        if (seen.has(uid)) {
            return false;
        }
        seen.add(uid);
        return true;
    });
}

function escapeHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function escapeHtmlAttribute(value) {
    return escapeHtml(value).replace(/\n/g, "&#10;");
}

async function copyTextToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return;
    }

    const temp = document.createElement("textarea");
    temp.value = text;
    temp.setAttribute("readonly", "");
    temp.style.position = "fixed";
    temp.style.left = "-9999px";
    document.body.appendChild(temp);
    temp.select();
    temp.setSelectionRange(0, temp.value.length);

    const successful = document.execCommand("copy");
    document.body.removeChild(temp);

    if (!successful) {
        throw new Error("Copy command failed");
    }
}

function bindCopyBioButtons(container = document) {
    if (!container || typeof container.querySelectorAll !== "function") {
        return;
    }
    container.querySelectorAll(".copy-player-bio").forEach((button) => {
        if (button.dataset.bound === "1") {
            return;
        }
        button.dataset.bound = "1";
        button.addEventListener("click", async () => {
            const bioText = button.dataset.bio || "";
            if (!bioText || bioText === "No bio found.") {
                if (window.showToast) {
                    window.showToast("No bio available to copy.", "error");
                }
                return;
            }
            try {
                await copyTextToClipboard(bioText);
                button.textContent = "Copied!";
                button.classList.add("bg-emerald-400/15", "border-emerald-400/20", "text-emerald-300");
                button.classList.remove("bg-cyan-400/10", "border-cyan-400/20", "text-cyan-200");
                setTimeout(() => {
                    button.textContent = "Copy Bio";
                    button.classList.remove("bg-emerald-400/15", "border-emerald-400/20", "text-emerald-300");
                    button.classList.add("bg-cyan-400/10", "border-cyan-400/20", "text-cyan-200");
                }, 2000);
                if (window.showToast) {
                    window.showToast("Bio copied successfully", "success");
                }
            } catch (error) {
                if (window.showToast) {
                    window.showToast("Failed to copy bio.", "error");
                }
            }
        });
    });
}

function renderToolCards(result) {
    const container = document.getElementById("toolOutput");
    if (!container) {
        return;
    }

    container.style.opacity = '0';
    container.style.transform = 'translateY(8px)';

    if (Array.isArray(result?.data)) {
        const uniquePlayers = dedupePlayersByUid(result.data);
        container.innerHTML = uniquePlayers.map(playerCardHtml).join("");
        bindCopyBioButtons(container);
    } else if (result?.player) {
        container.innerHTML = playerCardHtml(result.player);
        bindCopyBioButtons(container);
    } else if (result?.player_info) {
        container.innerHTML = playerCardHtml(result.player_info);
        bindCopyBioButtons(container);
    } else {
        container.innerHTML = "";
    }

    requestAnimationFrame(() => {
        container.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        container.style.opacity = '1';
        container.style.transform = 'translateY(0)';
    });
}

function renderFriendListCard(result) {
    const title = document.getElementById("tool-response-title");
    const message = document.getElementById("tool-response-message");
    const friends = dedupePlayersByUid(result.data);
    if (title) title.textContent = "Friend List";
    if (message) message.textContent = friends.length ? `Successfully loaded ${friends.length} friend${friends.length > 1 ? "s" : ""}.` : "No friends found.";

    if (!friends.length) {
        renderToolCards(null);
        return;
    }
    renderToolCards(result);
}

function formatToolMessage(result, action) {
    if (result?.ok === false) {
        return result.message || "Action was unsuccessful.";
    }

    const messages = {
        add_friend: result?.player?.name ? `Successfully added ${result.player.name}.` : "Friend added successfully.",
        remove_friend: "Friend removed successfully.",
        join_guild: "Guild joined successfully.",
        leave_guild: "Guild left successfully."
    };

    return messages[action] || result?.message || "Action completed successfully.";
}

async function refreshBotLogs() {
    const output = document.getElementById("bot-logs");
    if (!output) {
        return;
    }

    try {
        const response = await fetch("/api/logs");
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(payload.error || "Failed to load logs");
        }
        const bot = payload.bot || {};
        setConsoleState(bot.running ? "Live console: bot running" : "Live console: bot stopped");
        setBotLogs(payload.logs || []);
    } catch (error) {
        setConsoleState("Live console unavailable");
        output.textContent = error.message;
    }
}

async function refreshBotStatus() {
    const heroStatus = document.getElementById("hero-status");
    if (!heroStatus) {
        return;
    }

    try {
        const response = await fetch("/api/get_status");
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(payload.error || "Failed to load status");
        }

        const bot = payload.bot || {};
        const account = payload.account || {};
        const tokenInfo = payload.token_info || {};
        const running = !!bot.running;

        heroStatus.textContent = bot.status || "Stopped";
        heroStatus.className = `text-lg font-semibold ${running ? "text-emerald-300" : "text-rose-300"}`;
        setConsoleState(running ? "Live console: bot running" : "Live console: bot stopped");
        setText("status-uid", account.uid || "Not configured");
        setText("status-region", tokenInfo.region || account.region || "N/A");
        setText("status-bot-uid", tokenInfo.bot_uid || "Unknown");
    } catch (error) {
        setText("dashboard-result", error.message);
    }
}

async function refreshAccountInfo(button = null) {
    if (button) {
        setLoading(button, true);
    }

    try {
        const response = await fetch("/api/account_info");
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(payload.error || "Failed to load account info");
        }

        const info = payload.account_info || {};
        setText("account-name", info.name || "Unknown");
        setText("account-uid", info.uid || "Unknown");
        setText("account-level", info.level || "Unknown");
        setText("account-region", info.region || "Unknown");
        setBioText(info.bio || "");
        setText("copy-bio-status", "");
        return {
            ok: true,
            hasRealInfo: Boolean(
                (info.name && info.name !== "Unknown") ||
                (info.uid && info.uid !== "Unknown" && info.uid !== "Not configured") ||
                (info.level && info.level !== "Unknown") ||
                (info.region && info.region !== "Unknown")
            )
        };
    } catch (error) {
        const quietErrors = [
            "No saved game account found",
            "No active token found",
            "No UID available to fetch account info"
        ];
        const shouldQuiet = quietErrors.some((text) => error.message.includes(text));

        setText("account-name", "Unknown");
        setText("account-uid", "Not configured");
        setText("account-level", "Unknown");
        setText("account-region", "Unknown");
        setBioText("No bio found.");

        if (!shouldQuiet && window.showToast) {
            window.showToast(error.message, "error");
        }
        return { ok: false, quiet: shouldQuiet };
    } finally {
        if (button) {
            setLoading(button, false);
        }
    }
}

function stopAccountInfoCapture() {
    if (accountInfoCaptureInterval) {
        window.clearInterval(accountInfoCaptureInterval);
        accountInfoCaptureInterval = null;
    }
    accountInfoCaptureAttempts = 0;
}

function resetAccountInfoDisplay() {
    setText("account-name", "Unknown");
    setText("account-uid", "Not configured");
    setText("account-level", "Unknown");
    setText("account-region", "Unknown");
    setBioText("No bio found.");
    setText("copy-bio-status", "");
}

async function runAccountInfoCaptureTick() {
    accountInfoCaptureAttempts += 1;
    const result = await refreshAccountInfo();
    if (result?.hasRealInfo) {
        stopAccountInfoCapture();
        return;
    }
    if (accountInfoCaptureAttempts >= MAX_ACCOUNT_INFO_ATTEMPTS) {
        stopAccountInfoCapture();
    }
}

function startAccountInfoCapture() {
    stopAccountInfoCapture();
    accountInfoCaptureAttempts = 0;
    runAccountInfoCaptureTick();
    accountInfoCaptureInterval = window.setInterval(runAccountInfoCaptureTick, 2000);
}

document.querySelectorAll("[data-api-action]").forEach((button) => {
    button.addEventListener("click", async () => {
        const endpoint = button.dataset.apiAction;
        setText("dashboard-result", "Working...");
        setLoading(button, true);
        try {
            const result = await postJson(endpoint);
            setText("dashboard-result", result.message || "Success");
            if (window.showToast) {
                window.showToast(result.message || "Action completed.", "success");
            }
            refreshBotLogs();
            refreshBotStatus();
            if (endpoint === "/api/start_bot" || endpoint === "/api/restart_bot") {
                resetAccountInfoDisplay();
                startAccountInfoCapture();
            }
            if (endpoint === "/api/stop_bot") {
                stopAccountInfoCapture();
                resetAccountInfoDisplay();
            }
        } catch (error) {
            setText("dashboard-result", error.message);
            if (window.showToast) {
                window.showToast(error.message, "error");
            }
        } finally {
            setLoading(button, false);
        }
    });
});

document.querySelectorAll("[data-tool-action]").forEach((button) => {
    button.addEventListener("click", async () => {
        const action = button.dataset.toolAction;
        setToolResponseCard({ action, message: "Working..." });
        renderToolCards(null);
        setLoading(button, true);

        try {
            let result;
            if (action === "add_friend") {
                result = await postJson("/api/add_friend", {
                    target_uid: document.getElementById("friendUid").value
                });
                if (window.hideModal) window.hideModal("modal-add-friend");
            } else if (action === "remove_friend") {
                result = await postJson("/api/remove_friend", {
                    target_uid: document.getElementById("friendUidRemove").value
                });
                if (window.hideModal) window.hideModal("modal-remove-friend");
            } else if (action === "join_guild") {
                result = await postJson("/api/join_guild", {
                    guild_id: document.getElementById("guildId").value
                });
                if (window.hideModal) window.hideModal("modal-join-guild");
            } else if (action === "leave_guild") {
                result = await postJson("/api/leave_guild", {
                    guild_id: document.getElementById("guildIdLeave").value
                });
                if (window.hideModal) window.hideModal("modal-leave-guild");
            } else if (action === "friend_list") {
                const response = await fetch("/api/friend_list");
                const payload = await response.json();
                if (!response.ok) {
                    throw new Error(payload.error || "Request failed");
                }
                result = payload;
            }

            if (action === "friend_list") {
                renderFriendListCard(result);
            } else {
                setToolResponseCard({
                    action,
                    message: formatToolMessage(result, action)
                });
                renderToolCards(result);
            }
            if (window.showToast) {
                window.showToast(formatToolMessage(result, action), "success");
            }
        } catch (error) {
            setToolResponseCard({ message: `Unsuccessfully: ${error.message}` }, "Tool Error");
            renderToolCards(null);
            if (window.showToast) {
                window.showToast(error.message, "error");
            }
        } finally {
            setLoading(button, false);
        }
    });
});

const refreshLogsButton = document.getElementById("refresh-logs");
if (refreshLogsButton) {
    refreshLogsButton.addEventListener("click", refreshBotLogs);
    refreshBotLogs();
    refreshBotStatus();
    window.setInterval(refreshBotLogs, 3000);
    window.setInterval(refreshBotStatus, 3000);
}

const refreshAccountInfoButton = document.getElementById("refresh-account-info");
if (refreshAccountInfoButton) {
    refreshAccountInfoButton.addEventListener("click", () => refreshAccountInfo(refreshAccountInfoButton));
}

const copyBioButton = document.getElementById("copy-bio");

function bindDashboardBioCopy(button, statusId = "copy-bio-status") {
    if (!button) {
        return;
    }
    button.addEventListener("click", async () => {
        const bioText = document.getElementById("account-bio")?.textContent?.trim() || "";
        if (!bioText || bioText === "No bio found." || bioText === "Unable to load bio.") {
            setText(statusId, "No bio available to copy.");
            if (window.showToast) {
                window.showToast("No bio available to copy.", "error");
            }
            return;
        }

        try {
            await copyTextToClipboard(bioText);
            button.textContent = "Copied!";
            button.classList.add("bg-emerald-400/15", "border-emerald-400/20", "text-emerald-300");
            setTimeout(() => {
                button.textContent = "Copy Bio";
                button.classList.remove("bg-emerald-400/15", "border-emerald-400/20", "text-emerald-300");
            }, 2000);
            setText(statusId, "Bio copied successfully");
            if (window.showToast) {
                window.showToast("Bio copied successfully", "success");
            }
        } catch (error) {
            setText(statusId, "Copy failed");
            if (window.showToast) {
                window.showToast("Failed to copy bio.", "error");
            }
        }
    });
}

bindDashboardBioCopy(copyBioButton);
bindCopyBioButtons();
