import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="telegram.ext")

import sys
import os
import subprocess
import asyncio
import time
import shutil
import json
import re
import sqlite3
import signal
import aiohttp
from telegram import Update, KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters, ConversationHandler, ContextTypes, CallbackQueryHandler
)

ASK_LOGIN_TYPE = False 
DEFAULT_LOGIN_TYPE = 2   # 1 = Mobile, 2 = PC 

REQUIRED_CHANNEL = "@devilh3x"
CHANNEL_INVITE_LINK = "https://t.me/devilh3x"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BOTS_DIR = os.path.join(BASE_DIR, "BOTS")
DB_PATH = os.path.join(BASE_DIR, "bot_controller.db")

COPY_ITEMS = [
    "main.py", "xDL.py", "autoup.py", "Pb2", "protobuf_decoder",
    "dev_generator_pb2.py", "devxt_count_pb2.py", "kyro_title_pb2.py",
    "clan_pb2.py", "room_join_pb2.py", "emotes.json"
]

EXCLUDE_ITEMS = [
    "main.py", "bot_controller.db", "token.json", "__pycache__",
    "*.pyc", "*.log", "stop_*.txt"
]

WAITING_METHOD = 1
WAITING_ACC_UID = 2
WAITING_ACC_PASSWORD = 3
WAITING_DIRECT_TOKEN = 4
WAITING_LOGIN_TYPE = 5
WAITING_OWNER_UID = 6
WAITING_REGION = 7
WAITING_GUILD_ID = 8
WAITING_TARGET_UID = 9

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS accounts (
            user_id INTEGER PRIMARY KEY,
            login_method TEXT NOT NULL DEFAULT 'accs',
            login_type INTEGER NOT NULL DEFAULT 1,
            uid TEXT,
            password TEXT,
            access_token TEXT,
            owner_uid TEXT,
            folder_path TEXT,
            pid INTEGER,
            region TEXT DEFAULT 'IND',
            bot_name TEXT,
            bot_region TEXT
        )
    ''')
    c.execute("PRAGMA table_info(accounts)")
    columns = [col[1] for col in c.fetchall()]
    if 'login_method' not in columns:
        c.execute("ALTER TABLE accounts ADD COLUMN login_method TEXT NOT NULL DEFAULT 'accs'")
    if 'login_type' not in columns:
        c.execute("ALTER TABLE accounts ADD COLUMN login_type INTEGER NOT NULL DEFAULT 1")
    if 'access_token' not in columns:
        c.execute("ALTER TABLE accounts ADD COLUMN access_token TEXT")
    if 'owner_uid' not in columns:
        c.execute("ALTER TABLE accounts ADD COLUMN owner_uid TEXT")
    if 'folder_path' not in columns:
        c.execute("ALTER TABLE accounts ADD COLUMN folder_path TEXT")
    if 'pid' not in columns:
        c.execute("ALTER TABLE accounts ADD COLUMN pid INTEGER")
    if 'region' not in columns:
        c.execute("ALTER TABLE accounts ADD COLUMN region TEXT DEFAULT 'IND'")
    if 'bot_name' not in columns:
        c.execute("ALTER TABLE accounts ADD COLUMN bot_name TEXT")
    if 'bot_region' not in columns:
        c.execute("ALTER TABLE accounts ADD COLUMN bot_region TEXT")
    for col in ['open_id', 'emote_id']:
        try:
            c.execute(f"ALTER TABLE accounts DROP COLUMN {col}")
        except:
            pass
    conn.commit()
    conn.close()

def save_account(user_id: int, login_method: str, login_type: int, region: str = "IND",
                 uid: str = None, password: str = None,
                 access_token: str = None,
                 owner_uid: str = None, folder_path: str = None,
                 bot_name: str = None, bot_region: str = None):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        REPLACE INTO accounts 
        (user_id, login_method, login_type, uid, password, access_token, owner_uid, folder_path, pid, region, bot_name, bot_region)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?)
    """, (user_id, login_method, login_type, uid, password, access_token, owner_uid, folder_path, region, bot_name, bot_region))
    conn.commit()
    conn.close()

def get_account(user_id: int):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT login_method, login_type, uid, password, access_token, owner_uid, folder_path, pid, region, bot_name, bot_region FROM accounts WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    return row

def update_pid_and_folder(user_id: int, pid: int | None, folder_path: str = None, bot_name: str = None, bot_region: str = None):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    if folder_path:
        c.execute("UPDATE accounts SET pid = ?, folder_path = ? WHERE user_id = ?", (pid, folder_path, user_id))
    else:
        c.execute("UPDATE accounts SET pid = ? WHERE user_id = ?", (pid, user_id))
    if bot_name is not None:
        c.execute("UPDATE accounts SET bot_name = ? WHERE user_id = ?", (bot_name, user_id))
    if bot_region is not None:
        c.execute("UPDATE accounts SET bot_region = ? WHERE user_id = ?", (bot_region, user_id))
    conn.commit()
    conn.close()

def delete_account(user_id: int):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DELETE FROM accounts WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

def delete_user_folder(user_id: int):
    folder = os.path.join(BOTS_DIR, f"bot_{user_id}")
    if os.path.exists(folder):
        shutil.rmtree(folder)

def is_bot_running(user_id: int) -> bool:
    account = get_account(user_id)
    if not account:
        return False
    pid = account[7]
    if not pid or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        update_pid_and_folder(user_id, None, account[6])
        return False

def ignore_patterns(dirname, files):
    ignored = set()
    for pattern in EXCLUDE_ITEMS:
        if pattern.startswith('*'):
            ext = pattern[1:]
            ignored.update([f for f in files if f.endswith(ext)])
        else:
            if pattern in files:
                ignored.add(pattern)
    for f in files:
        if f.startswith("stop_") and f.endswith(".txt"):
            ignored.add(f)
    return ignored

def copy_bot_files(user_id: int, login_method: str, login_type: int, region: str,
                   uid: str = None, password: str = None,
                   access_token: str = None,
                   owner_uid: str = None) -> str:
    if not os.path.exists(BOTS_DIR):
        os.makedirs(BOTS_DIR)
    user_folder = os.path.join(BOTS_DIR, f"bot_{user_id}")
    if os.path.exists(user_folder):
        shutil.rmtree(user_folder)
    os.makedirs(user_folder)

    for item in COPY_ITEMS:
        src = os.path.join(BASE_DIR, item)
        dst = os.path.join(user_folder, item)
        if os.path.isdir(src):
            shutil.copytree(src, dst, ignore=ignore_patterns, dirs_exist_ok=True)
        elif os.path.isfile(src):
            shutil.copy2(src, dst)

    main_path = os.path.join(user_folder, "main.py")
    if os.path.exists(main_path):
        with open(main_path, 'r', encoding='utf-8') as f:
            content = f.read()
        pattern_owner = r'(OWNER_UID\s*=\s*["\'])(\d+)(["\'])'
        replacement_owner = rf'\g<1>{owner_uid}\g<3>'
        new_content = re.sub(pattern_owner, replacement_owner, content)
        if "OWNER_UID" not in new_content:
            insert_line = f'OWNER_UID = "{owner_uid}"'
            new_content = new_content.replace('WHITELISTED_UIDS = {', f'{insert_line}\n\nWHITELISTED_UIDS = {{')
        with open(main_path, 'w', encoding='utf-8') as f:
            f.write(new_content)

    if login_method == "accs":
        accs_data = {uid: password}
        accs_path = os.path.join(user_folder, "accs.txt")
        with open(accs_path, "w", encoding="utf-8") as f:
            json.dump(accs_data, f, indent=2)
    else:
        direct_path = os.path.join(user_folder, "direct.txt")
        with open(direct_path, "w", encoding="utf-8") as f:
            f.write(access_token + "\n")

    from admin_db import get_settings
    site_settings = get_settings()
    config = {
        "login_method": login_method,
        "login_type": login_type,
        "region": region,
        "auto_bio_enabled": site_settings.get("auto_bio_enabled", False),
        "auto_bio_text": site_settings.get("auto_bio_text", "")
    }
    config_path = os.path.join(user_folder, "bot_config.json")
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f)

    return user_folder

async def inspect_token(access_token: str):
    try:
        url = f"https://100067.connect.garena.com/oauth/token/inspect?token={access_token}"
        headers = {
            "User-Agent": "GarenaMSDK/4.0.19P4 (Vivo Y15c; Android 12; en;IN;)",
            "Connection": "close"
        }
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, ssl=False) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get('open_id')
    except Exception:
        pass
    return None

async def start_bot_process(user_id: int, login_method: str, login_type: int, region: str,
                            uid: str = None, password: str = None,
                            access_token: str = None,
                            owner_uid: str = None) -> tuple[bool, str]:
    open_id = None
    if login_method == "direct":
        open_id = await inspect_token(access_token)
        if not open_id:
            return False, "❌ Invalid or expired access token."

    folder = copy_bot_files(user_id, login_method, login_type, region,
                            uid, password, access_token, owner_uid)
    stop_file = os.path.join(folder, f"stop_{user_id}.txt")
    if os.path.exists(stop_file):
        os.remove(stop_file)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    cmd = [sys.executable, "-u", "main.py"]

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        cwd=folder,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env
    )

    account_name = None
    account_uid = None
    bot_region = None
    error_msg = None
    timeout = 60

    async def read_stdout():
        nonlocal account_name, account_uid, bot_region, error_msg
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            line = line.decode('utf-8', errors='ignore').strip()
            if not line:
                continue
            print(f"[SUBPROC] {line}")
            if "🔹 UID:" in line:
                parts = line.split("🔹 UID:")
                if len(parts) > 1:
                    account_uid = parts[1].strip()
            elif "🔹 Name:" in line:
                parts = line.split("🔹 Name:")
                if len(parts) > 1:
                    account_name = parts[1].strip()
            elif "🔹 Region:" in line:
                parts = line.split("🔹 Region:")
                if len(parts) > 1:
                    bot_region = parts[1].strip()
            elif line.startswith("[SUCCESS] Account Name:"):
                account_name = line.split(":", 1)[1].strip()
            elif line.startswith("[SUCCESS] Account UID:"):
                account_uid = line.split(":", 1)[1].strip()
            elif line.startswith("[SUCCESS] Region:"):
                bot_region = line.split(":", 1)[1].strip()
            elif line.startswith("[ERROR]"):
                error_msg = line.split("]", 1)[1].strip()
                break

    async def read_stderr():
        nonlocal error_msg
        while True:
            line = await proc.stderr.readline()
            if not line:
                break
            line = line.decode('utf-8', errors='ignore').strip()
            if line:
                print(f"[SUBPROC STDERR] {line}")
                if not error_msg:
                    error_msg = line

    stdout_task = asyncio.create_task(read_stdout())
    stderr_task = asyncio.create_task(read_stderr())

    start_time = time.time()
    success_detected = False
    while time.time() - start_time < timeout:
        if account_name and account_uid and bot_region:
            success_detected = True
            break
        if error_msg:
            break
        await asyncio.sleep(0.2)

    stdout_task.cancel()
    stderr_task.cancel()
    try:
        await stdout_task
    except asyncio.CancelledError:
        pass
    try:
        await stderr_task
    except asyncio.CancelledError:
        pass

    proc_alive = proc.returncode is None

    if success_detected:
        update_pid_and_folder(user_id, proc.pid, folder, bot_name=account_name, bot_region=bot_region)
        success_msg = (
            f"✅ <b>Bot Started Successfully!</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"👤 <b>Name:</b> <code>{account_name}</code>\n"
            f"🆔 <b>UID:</b> <code>{account_uid}</code>\n"
            f"🌍 <b>Region:</b> <code>{bot_region}</code>"
        )
        return True, success_msg
    else:
        if proc_alive:
            proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), timeout=5)
            except asyncio.TimeoutError:
                proc.kill()
        if os.path.exists(folder):
            shutil.rmtree(folder)
        if not error_msg:
            error_msg = "Bot failed to start (timeout or no success output). Check credentials and region."
        return False, f"❌ <b>Failed to start bot:</b>\n<code>{error_msg}</code>"

async def stop_bot_process(user_id: int) -> bool:
    account = get_account(user_id)
    if not account or len(account) < 7 or account[6] is None:
        return False
    login_method, login_type, uid, password, access_token, owner_uid, folder, pid, region, bot_name, bot_region = account
    if not pid:
        return False
    stop_file = os.path.join(folder, f"stop_{user_id}.txt")
    try:
        with open(stop_file, 'w') as f:
            f.write("stop")
        os.kill(pid, signal.SIGTERM)
    except:
        pass
    update_pid_and_folder(user_id, None, folder)
    return True

async def is_user_member(user_id: int, context: ContextTypes.DEFAULT_TYPE) -> bool:
    try:
        member = await context.bot.get_chat_member(chat_id=REQUIRED_CHANNEL, user_id=user_id)
        return member.status in ["member", "administrator", "creator"]
    except Exception:
        return False

def verification_keyboard():
    buttons = [[KeyboardButton("✅ Verify")]]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True, one_time_keyboard=True)

async def send_verification_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        f"🔐 <b>Access Restricted</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"You need to join our official channel before using this bot.\n\n"
        f"👉 Channel: {CHANNEL_INVITE_LINK}\n\n"
        f"After joining, click the <b>Verify</b> button below."
    )
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=verification_keyboard())

async def handle_verify_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if await is_user_member(user_id, context):
        await update.message.reply_text(
            "✅ <b>Verification Successful</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Welcome to the bot. Use the menu below to get started.",
            parse_mode="HTML",
            reply_markup=main_menu_keyboard()
        )
    else:
        await update.message.reply_text(
            "❌ You haven't joined the channel yet.\nPlease join first, then click Verify again.",
            reply_markup=verification_keyboard()
        )

async def verify_membership_and_proceed(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    user_id = update.effective_user.id
    if await is_user_member(user_id, context):
        return True
    else:
        await send_verification_message(update, context)
        return False

def private_chat_only(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        if update.effective_chat.type != "private":
            await update.message.reply_text(
                "🔒 This bot works only in private messages.\nPlease message me directly: @"
                + (await context.bot.get_me()).username
            )
            return
        return await func(update, context, *args, **kwargs)
    return wrapper

def main_menu_keyboard():
    buttons = [
        [KeyboardButton("🤖 Bot Management")],
        [KeyboardButton("👥 Social Actions")],
        [KeyboardButton("📘 Help & Info")]
    ]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)

def bot_menu_keyboard():
    buttons = [
        [KeyboardButton("➕ Add Bot")],
        [KeyboardButton("▶️ Start Bot")],
        [KeyboardButton("⏹️ Stop Bot")],
        [KeyboardButton("🗑️ Remove Bot")],
        [KeyboardButton("📊 Bot Status")],
        [KeyboardButton("◀️ Back to Main Menu")]
    ]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)

def social_menu_keyboard():
    buttons = [
        [KeyboardButton("👤 Add Friend")],
        [KeyboardButton("🚫 Remove Friend")],
        [KeyboardButton("🏰 Join Guild")],
        [KeyboardButton("🚪 Leave Guild")],
        [KeyboardButton("◀️ Back to Main Menu")]
    ]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)

def method_choice_keyboard():
    keyboard = [
        [InlineKeyboardButton("📱 UID + Password", callback_data="method_accs")],
        [InlineKeyboardButton("🔑 AccessToken", callback_data="method_direct")]
    ]
    return InlineKeyboardMarkup(keyboard)

def login_type_keyboard():
    keyboard = [
        [InlineKeyboardButton("📱 Mobile", callback_data="logintype_1")],
        [InlineKeyboardButton("💻 PC", callback_data="logintype_2")]
    ]
    return InlineKeyboardMarkup(keyboard)

def region_keyboard():
    keyboard = [
        [InlineKeyboardButton("🇮🇳 IND", callback_data="region_IND"),
         InlineKeyboardButton("🇮🇩 ID", callback_data="region_ID")],
        [InlineKeyboardButton("🇧🇷 BR", callback_data="region_BR"),
         InlineKeyboardButton("🇲🇪 ME", callback_data="region_ME")],
        [InlineKeyboardButton("🇻🇳 VN", callback_data="region_VN"),
         InlineKeyboardButton("🇹🇭 TH", callback_data="region_TH")],
        [InlineKeyboardButton("🇵🇰 PK", callback_data="region_PK"),
         InlineKeyboardButton("🇧🇩 BD", callback_data="region_BD")]
    ]
    return InlineKeyboardMarkup(keyboard)

from xDL import *
from main import (
    GeNeRaTeAccEss, EncRypTMajoRLoGin_mobile, EncRypTMajoRLoGin_pc,
    MajorLogin, DecRypTMajoRLoGin,
    RequestJoinClan, QuitClan, RequestAddingFriend_Uid_async, DeLet_Uid
)

async def execute_action(user_id: int, action: str, param: str) -> str:
    account = get_account(user_id)
    if not account:
        return "❌ No bot Added. Use 'Add Bot' first."
    if not is_bot_running(user_id):
        return "❌ Bot is not running. Please start the bot first using 'Start Bot'."

    login_method, login_type, uid, password, access_token, owner_uid, folder, pid, region, bot_name, bot_region = account

    if login_method == "accs":
        open_id, access_token = await GeNeRaTeAccEss(uid, password)
        if not open_id or not access_token:
            return "❌ Authentication failed (wrong UID/password)."
    else:
        open_id = await inspect_token(access_token)
        if not open_id:
            return "❌ Invalid or expired access token."

    if login_type == 1:
        encrypted_login = await EncRypTMajoRLoGin_mobile(open_id, access_token, region=region)
    else:
        encrypted_login = await EncRypTMajoRLoGin_pc(open_id, access_token)

    login_response = await MajorLogin(encrypted_login)
    if not login_response:
        return "❌ MajorLogin failed (account may be banned)."
    login_data = await DecRypTMajoRLoGin(login_response)
    token = login_data.token
    if not token:
        return "❌ No token received."

    if action == "guild_join":
        result = await RequestJoinClan(param, token, region)
        return result or "❌ Guild join request failed."
    elif action == "guild_leave":
        result = await QuitClan(param, token, region)
        return result or "❌ Guild leave failed."
    elif action == "add_friend":
        result = await RequestAddingFriend_Uid_async(param, token, region)
        return result or "❌ Friend request failed."
    elif action == "remove_friend":
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(None, DeLet_Uid, param, token, region)
        return result or "❌ Remove friend failed."
    else:
        return "⚠️ Unknown action."

def get_method_display(login_method: str) -> str:
    return "UID + Password" if login_method == "accs" else "AccessToken"

@private_chat_only
async def add_bot_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await verify_membership_and_proceed(update, context):
        return ConversationHandler.END
    await update.message.reply_text(
        "🔐 <b>Add a New Bot</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n\n"
        "Choose login method:",
        parse_mode="HTML",
        reply_markup=method_choice_keyboard()
    )
    return WAITING_METHOD

async def method_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    method = query.data.split("_")[1]
    context.user_data['login_method'] = method
    if method == "accs":
        await query.edit_message_text(
        "📱 <b>UID + Password</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n\n"
        "Send the guest account login UID:\nType /cancel to abort.",
        parse_mode="HTML",
        reply_markup=None
    )
        return WAITING_ACC_UID
    else:
        await query.edit_message_text(
        "🔑 <b>AccessToken</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n\n"
        "Send the AccessToken (one line):\nType /cancel to abort.",
        parse_mode="HTML",
        reply_markup=None
    )
        return WAITING_DIRECT_TOKEN

@private_chat_only
async def acc_uid_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.message.text.strip()
    if not uid.isdigit() or len(uid) < 8:
        await update.message.reply_text("❌ Invalid UID. Must be at least 8 digits. Try again (or /cancel):")
        return WAITING_ACC_UID
    context.user_data['uid'] = uid
    await update.message.reply_text("🔑 Now send the guest account login password (or /cancel):")
    return WAITING_ACC_PASSWORD

@private_chat_only
async def acc_password_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    password = update.message.text.strip()
    if not password:
        await update.message.reply_text("❌ Password cannot be empty. Try again (or /cancel):")
        return WAITING_ACC_PASSWORD
    context.user_data['password'] = password

    if ASK_LOGIN_TYPE:
        await update.message.reply_text(
            "🤖 <b>Login Type</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Choose one:",
            parse_mode="HTML",
            reply_markup=login_type_keyboard()
        )
        return WAITING_LOGIN_TYPE
    else:
        context.user_data['login_type'] = DEFAULT_LOGIN_TYPE
        await update.message.reply_text(
            "🌍 <b>Select your bot's region</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Choose the region where your bot account is registered:",
            parse_mode="HTML",
            reply_markup=region_keyboard()
        )
        return WAITING_REGION

@private_chat_only
async def direct_token_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    access_token = update.message.text.strip()
    if not access_token:
        await update.message.reply_text("❌ AccessToken cannot be empty. Try again (or /cancel):")
        return WAITING_DIRECT_TOKEN
    open_id = await inspect_token(access_token)
    if not open_id:
        await update.message.reply_text(
            "❌ Invalid or expired AccessToken. Please check your token.\nType /cancel to abort."
        )
        return WAITING_DIRECT_TOKEN
    context.user_data['access_token'] = access_token

    if ASK_LOGIN_TYPE:
        await update.message.reply_text(
            "🤖 <b>Login Type</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Choose one:",
            parse_mode="HTML",
            reply_markup=login_type_keyboard()
        )
        return WAITING_LOGIN_TYPE
    else:
        context.user_data['login_type'] = DEFAULT_LOGIN_TYPE
        await update.message.reply_text(
            "🌍 <b>Select your bot's region</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Choose the region where your bot account is registered:",
            parse_mode="HTML",
            reply_markup=region_keyboard()
        )
        return WAITING_REGION

async def login_type_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    lt = int(query.data.split("_")[1])
    context.user_data['login_type'] = lt
    await query.edit_message_text(
        "🌍 *Select your bot's region*\n\nChoose the region where your bot account is registered:",
        parse_mode="Markdown",
        reply_markup=region_keyboard()
    )
    return WAITING_REGION

async def region_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    region = query.data.split("_")[1]
    context.user_data['region'] = region
    await query.edit_message_text(
        "👤 <b>Owner UID</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n\n"
        "Send the UID that will be set as <code>OWNER_UID</code> in the bot configuration.\nType /cancel to abort.",
        parse_mode="HTML",
        reply_markup=None
    )
    return WAITING_OWNER_UID

@private_chat_only
async def owner_uid_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    owner_uid = update.message.text.strip()
    if not owner_uid.isdigit() or len(owner_uid) < 8:
        await update.message.reply_text("❌ Invalid Owner UID. Must be at least 8 digits. Try again (or /cancel):")
        return WAITING_OWNER_UID
    context.user_data['owner_uid'] = owner_uid
    user_id = update.effective_user.id
    login_method = context.user_data['login_method']
    login_type = context.user_data['login_type']
    region = context.user_data['region']
    if login_method == "accs":
        uid = context.user_data['uid']
        password = context.user_data['password']
        save_account(user_id, login_method, login_type, region,
                     uid=uid, password=password,
                     access_token=None,
                     owner_uid=owner_uid)
    else:
        access_token = context.user_data['access_token']
        save_account(user_id, login_method, login_type, region,
                     uid=None, password=None,
                     access_token=access_token,
                     owner_uid=owner_uid)
    method_display = get_method_display(login_method)
    await update.message.reply_text(
        f"✅ <b>Bot Added Successfully</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"• Method: <code>{method_display}</code>\n"
        f"• Owner UID: <code>{owner_uid}</code>\n"
        f"• Login Type: <code>{'Mobile' if login_type==1 else 'PC'}</code>\n"
        f"• Region: <code>{region}</code>\n\n"
        f"Use <b>Start Bot</b> from the Bot Management menu to launch.",
        parse_mode="HTML",
        reply_markup=main_menu_keyboard()
    )
    return ConversationHandler.END

async def action_start(update: Update, context: ContextTypes.DEFAULT_TYPE, action: str):
    if update.effective_chat.type != "private":
        await update.message.reply_text("🔒 This bot works only in private messages.")
        return ConversationHandler.END
    if not await verify_membership_and_proceed(update, context):
        return ConversationHandler.END

    user_id = update.effective_user.id
    account = get_account(user_id)
    if not account:
        await update.message.reply_text(
            "❌ No bot Added. Use 'Add Bot' first.",
            reply_markup=social_menu_keyboard()
        )
        return ConversationHandler.END
    if not is_bot_running(user_id):
        await update.message.reply_text(
            "❌ Bot is not running. Please start the bot first using 'Start Bot'.",
            reply_markup=social_menu_keyboard()
        )
        return ConversationHandler.END

    context.user_data['action'] = action
    if action in ["guild_join", "guild_leave"]:
        await update.message.reply_text(
            f"🏰 <b>{action.replace('_', ' ').title()}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Send the Clan ID (numeric only):\nType /cancel to abort.",
            parse_mode="HTML",
            reply_markup=ReplyKeyboardRemove()
        )
        return WAITING_GUILD_ID
    else:
        await update.message.reply_text(
            f"👥 <b>{action.replace('_', ' ').title()}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Send the target UID (9-10 digits):\nType /cancel to abort.",
            parse_mode="HTML",
            reply_markup=ReplyKeyboardRemove()
        )
        return WAITING_TARGET_UID

@private_chat_only
async def param_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    param = update.message.text.strip()
    action = context.user_data.get('action')
    if action in ['guild_join', 'guild_leave']:
        if not param.isdigit():
            await update.message.reply_text("❌ Clan ID must be numbers only. Try again (or /cancel):")
            return WAITING_GUILD_ID
    else:
        if not param.isdigit() or len(param) < 8:
            await update.message.reply_text("❌ Invalid UID. Must be 8+ digits. Try again (or /cancel):")
            return WAITING_TARGET_UID
    user_id = update.effective_user.id
    await update.message.reply_text("⏳ Processing request...")
    result = await execute_action(user_id, action, param)
    await update.message.reply_text(result, reply_markup=social_menu_keyboard(), parse_mode=None)
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.message.reply_text(
        "❌ <b>Operation cancelled.</b> Returning to main menu.",
        parse_mode="HTML",
        reply_markup=main_menu_keyboard()
    )
    return ConversationHandler.END

@private_chat_only
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await verify_membership_and_proceed(update, context):
        return
    await update.message.reply_text(
        "🤖 <b>TCP Bot Panel</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n\n"
        "Welcome! Use the buttons below to navigate.",
        parse_mode="HTML",
        reply_markup=main_menu_keyboard()
    )

@private_chat_only
async def handle_menu_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    user_id = update.effective_user.id

    if text == "🤖 Bot Management":
        if not await verify_membership_and_proceed(update, context):
            return
        await update.message.reply_text(
            "⚙️ <b>Bot Management</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Select an action for your bot.",
            parse_mode="HTML",
            reply_markup=bot_menu_keyboard()
        )
    elif text == "👥 Social Actions":
        if not await verify_membership_and_proceed(update, context):
            return
        account = get_account(user_id)
        if not account:
            await update.message.reply_text(
                "❌ No bot Added. Use 'Add Bot' first.\n\nAfter adding, use 'Start Bot' to launch.",
                reply_markup=main_menu_keyboard()
            )
            return
        if not is_bot_running(user_id):
            await update.message.reply_text(
                "❌ Bot is not running. Please start the bot first using 'Start Bot'.",
                reply_markup=main_menu_keyboard()
            )
            return
        await update.message.reply_text(
            "👥 <b>Social Actions</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Manage friends and guilds using your bot's token.",
            parse_mode="HTML",
            reply_markup=social_menu_keyboard()
        )
    elif text == "📘 Help & Info":
        if not await verify_membership_and_proceed(update, context):
            return
        help_text = (
            "📘 <b>Help & Information</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "🤖 <b>Bot Management</b>\n"
            "  ➕ <b>Add Bot</b> — Save your bot credentials\n"
            "  ▶️ <b>Start Bot</b> — Launch the bot process\n"
            "  ⏹️ <b>Stop Bot</b> — Terminate the running bot\n"
            "  🗑️ <b>Remove Bot</b> — Delete bot data\n"
            "  📊 <b>Status</b> — Check bot status &amp; account details\n\n"
            "👥 <b>Social Actions</b>\n"
            "  👤 <b>Add Friend</b> — Send friend request\n"
            "  🚫 <b>Remove Friend</b> — Remove a friend\n"
            "  🏰 <b>Join Guild</b> — Request to join a clan\n"
            "  🚪 <b>Leave Guild</b> — Leave current clan\n\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "⚠️ Each user can add only <b>ONE</b> bot.\n"
            "Adding a new bot replaces the previous one.\n\n"
            "❓ Need help? Contact <b>@devilh3x</b>"
        )
        await update.message.reply_text(help_text, parse_mode="HTML", reply_markup=main_menu_keyboard())
    elif text == "▶️ Start Bot":
        if not await verify_membership_and_proceed(update, context):
            return
        row = get_account(user_id)
        if not row:
            await update.message.reply_text("❌ No bot Added. Use 'Add Bot' first.", reply_markup=bot_menu_keyboard())
            return
        login_method, login_type, uid, password, access_token, owner_uid, folder, pid, region, bot_name, bot_region = row
        if not owner_uid:
            await update.message.reply_text(
                "❌ Owner UID missing. Please re-Add your bot.",
                reply_markup=bot_menu_keyboard()
            )
            return
        if pid and pid > 0:
            try:
                os.kill(pid, 0)
                await update.message.reply_text("⚠️ Bot is already running.", reply_markup=bot_menu_keyboard())
                return
            except OSError:
                update_pid_and_folder(user_id, None, folder)
        status_msg = await update.message.reply_text("⏳ Starting bot...")
        success, result_msg = await start_bot_process(user_id, login_method, login_type, region,
                                                       uid, password, access_token, owner_uid)
        await status_msg.delete()
        await update.message.reply_text(result_msg, parse_mode="HTML", reply_markup=bot_menu_keyboard())
    elif text == "⏹️ Stop Bot":
        if not await verify_membership_and_proceed(update, context):
            return
        success = await stop_bot_process(user_id)
        if success:
            await update.message.reply_text("✅ <b>Bot stopped successfully.</b>", parse_mode="HTML", reply_markup=bot_menu_keyboard())
        else:
            await update.message.reply_text("⚠️ <b>Bot was not running or not Added.</b>", parse_mode="HTML", reply_markup=bot_menu_keyboard())
    elif text == "🗑️ Remove Bot":
        if not await verify_membership_and_proceed(update, context):
            return
        row = get_account(user_id)
        if not row:
            await update.message.reply_text("❌ <b>No bot to remove.</b>", parse_mode="HTML", reply_markup=bot_menu_keyboard())
        else:
            await stop_bot_process(user_id)
            delete_user_folder(user_id)
            delete_account(user_id)
            await update.message.reply_text("✅ <b>Bot removed successfully.</b>", parse_mode="HTML", reply_markup=main_menu_keyboard())
    elif text == "📊 Bot Status":
        if not await verify_membership_and_proceed(update, context):
            return
        row = get_account(user_id)
        if not row:
            await update.message.reply_text("No bot Added.", reply_markup=bot_menu_keyboard())
        else:
            login_method, login_type, uid, password, access_token, owner_uid, folder, pid, region, bot_name, bot_region = row
            running = False
            if pid and pid > 0:
                try:
                    os.kill(pid, 0)
                    running = True
                except OSError:
                    running = False
                    update_pid_and_folder(user_id, None, folder)
            status_text = "🟢 <b>Running</b>" if running else "🔴 <b>Stopped</b>"
            method_display = get_method_display(login_method)
            login_type_display = "Mobile" if login_type == 1 else "PC"
            display_region = bot_region if bot_region else region
            msg = f"📊 <b>Bot Status</b>\n"
            msg += f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
            msg += f"• Method: <code>{method_display}</code>\n"
            msg += f"• Login Type: <code>{login_type_display}</code>\n"
            if bot_name:
                msg += f"• Bot Name: <code>{bot_name}</code>\n"
            msg += f"• Region: <code>{display_region}</code>\n"
            msg += f"• Status: {status_text}"
            await update.message.reply_text(msg, parse_mode="HTML", reply_markup=bot_menu_keyboard())
    elif text == "◀️ Back to Main Menu":
        await update.message.reply_text(
            "🤖 <b>TCP Bot Panel</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Welcome! Use the buttons below to navigate.",
            parse_mode="HTML",
            reply_markup=main_menu_keyboard()
        )

def main():
    init_db()
    TOKEN = "8682829610:AAGXCEN_uHbrNNGnSS55xO_byDQdaBXfDw8"
    app = Application.builder().token(TOKEN).build()

    add_bot_conv_states = {
        WAITING_METHOD: [CallbackQueryHandler(method_callback, pattern="^method_")],
        WAITING_ACC_UID: [MessageHandler(filters.TEXT & ~filters.COMMAND, acc_uid_input)],
        WAITING_ACC_PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, acc_password_input)],
        WAITING_DIRECT_TOKEN: [MessageHandler(filters.TEXT & ~filters.COMMAND, direct_token_input)],
        WAITING_REGION: [CallbackQueryHandler(region_callback, pattern="^region_")],
        WAITING_OWNER_UID: [MessageHandler(filters.TEXT & ~filters.COMMAND, owner_uid_input)],
    }
    if ASK_LOGIN_TYPE:
        add_bot_conv_states[WAITING_LOGIN_TYPE] = [CallbackQueryHandler(login_type_callback, pattern="^logintype_")]

    add_bot_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^➕ Add Bot$"), add_bot_start)],
        states=add_bot_conv_states,
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True
    )

    action_conv = ConversationHandler(
        entry_points=[
            MessageHandler(filters.Regex("^👤 Add Friend$"), lambda u,c: action_start(u,c,"add_friend")),
            MessageHandler(filters.Regex("^🚫 Remove Friend$"), lambda u,c: action_start(u,c,"remove_friend")),
            MessageHandler(filters.Regex("^🏰 Join Guild$"), lambda u,c: action_start(u,c,"guild_join")),
            MessageHandler(filters.Regex("^🚪 Leave Guild$"), lambda u,c: action_start(u,c,"guild_leave")),
        ],
        states={
            WAITING_GUILD_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, param_input)],
            WAITING_TARGET_UID: [MessageHandler(filters.TEXT & ~filters.COMMAND, param_input)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.Regex("^✅ Verify$"), handle_verify_button))
    app.add_handler(add_bot_conv)
    app.add_handler(action_conv)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_menu_text))

    print("🤖 Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()