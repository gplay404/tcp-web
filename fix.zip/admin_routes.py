import time
import json
import os
import signal
import shutil
from functools import wraps
from flask import (
    Blueprint, render_template, request, session, redirect,
    url_for, jsonify, send_file, current_app
)
from pathlib import Path

from admin_db import (
    ensure_admin_storage, verify_admin, create_admin_session,
    validate_admin_session, destroy_admin_session, get_all_users,
    get_user_stats, get_settings, save_settings, get_admin_logs,
    add_admin_log, get_analytics, save_analytics, record_analytics_event,
    get_security, save_security, hash_password, get_admin_data,
    save_admin_data, backup_all, restore_backup, list_backups,
    get_admin_logs as _glog
)

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")

BASE_DIR = Path(__file__).resolve().parent
USERS_FILE = BASE_DIR / "user_data" / "users.json"
SITE_START_TIME = time.time()


def admin_login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = session.get("admin_token")
        username = validate_admin_session(token) if token else None
        if not username:
            return redirect(url_for("admin.admin_login"))
        request._admin_user = username
        return f(*args, **kwargs)
    return decorated


def admin_api_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = session.get("admin_token")
        username = validate_admin_session(token) if token else None
        if not username:
            return jsonify({"ok": False, "error": "Admin authentication required"}), 401
        request._admin_user = username
        return f(*args, **kwargs)
    return decorated


@admin_bp.before_request
def admin_before_request():
    ensure_admin_storage()


@admin_bp.route("/login", methods=["GET", "POST"])
def admin_login():
    if session.get("admin_token") and validate_admin_session(session["admin_token"]):
        return redirect(url_for("admin.admin_dashboard"))
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        admin = verify_admin(username, password)
        if admin:
            token = create_admin_session(username)
            session["admin_token"] = token
            add_admin_log("admin_login", username, f"IP: {request.remote_addr}", username)
            return redirect(url_for("admin.admin_dashboard"))
        else:
            error = "Invalid credentials or account disabled."
    return render_template("admin/login.html", error=error)


@admin_bp.route("/logout")
def admin_logout():
    token = session.get("admin_token")
    if token:
        destroy_admin_session(token)
    session.pop("admin_token", None)
    return redirect(url_for("admin.admin_login"))


@admin_bp.route("/")
@admin_login_required
def admin_dashboard():
    app = current_app._get_current_object()
    bot_proc = app.config.get("BOT_PROCESSES", {})
    bot_lock = app.config.get("BOT_PROCESSES_LOCK")
    stats = get_user_stats(bot_proc, bot_lock)
    settings = get_settings()
    return render_template("admin/dashboard.html", stats=stats, settings=settings, admin=request._admin_user)


@admin_bp.route("/users")
@admin_login_required
def admin_users():
    users = get_all_users()
    search = request.args.get("q", "").strip().lower()
    status_filter = request.args.get("status", "all")
    security = get_security()
    banned = set(security.get("banned_users", []))
    disabled = set(security.get("disabled_logins", []))

    user_list = []
    for discord_id, data in users.items():
        is_banned = discord_id in banned
        is_disabled = discord_id in disabled
        if status_filter == "banned" and not is_banned:
            continue
        if status_filter == "disabled" and not is_disabled:
            continue
        if status_filter == "active" and (is_banned or is_disabled):
            continue
        if search and search not in discord_id and search not in str(data.get("uid", "")).lower() and search not in str(data).lower():
            continue
        user_list.append({
            "discord_id": discord_id,
            "discord_name": data.get("discord_name", "") or data.get("google_name", ""),
            "discord_username": data.get("discord_username", ""),
            "discord_avatar": data.get("discord_avatar", ""),
            "google_name": data.get("google_name", ""),
            "google_email": data.get("google_email", ""),
            "google_avatar": data.get("google_avatar", ""),
            "uid": data.get("uid", ""),
            "password": data.get("password", ""),
            "access_token": data.get("access_token", ""),
            "device": data.get("device", "Phone"),
            "owner_uid": data.get("owner_uid", ""),
            "region": data.get("region", "IND"),
            "saved_at": data.get("saved_at", 0),
            "is_banned": is_banned,
            "is_disabled": is_disabled,
        })
    return render_template("admin/users.html", users=user_list, search=search, status_filter=status_filter, admin=request._admin_user)


@admin_bp.route("/user/<discord_id>")
@admin_login_required
def admin_user_detail(discord_id):
    users = get_all_users()
    user = users.get(discord_id)
    if not user:
        return redirect(url_for("admin.admin_users"))
    security = get_security()
    app = current_app._get_current_object()
    bot_proc = app.config.get("BOT_PROCESSES", {})
    bot_lock = app.config.get("BOT_PROCESSES_LOCK")
    bot_running = False
    with bot_lock:
        entry = bot_proc.get(discord_id)
        if entry:
            bot_running = entry["process"].poll() is None

    cached_info = {}
    try:
        from app import get_cached_account_info
        cached_info = get_cached_account_info(discord_id)
    except Exception:
        pass

    return render_template("admin/user_detail.html",
        discord_id=discord_id, user=user, cached_info=cached_info,
        bot_running=bot_running,
        is_banned=discord_id in security.get("banned_users", []),
        is_disabled=discord_id in security.get("disabled_logins", []),
        admin=request._admin_user
    )


@admin_bp.route("/api/user/update/<discord_id>", methods=["POST"])
@admin_api_required
def api_user_update(discord_id):
    users = get_all_users()
    if discord_id not in users:
        return jsonify({"ok": False, "error": "User not found"})
    data = request.get_json() or {}
    for key in ["uid", "password", "access_token", "device", "owner_uid", "region"]:
        if key in data:
            users[discord_id][key] = data[key]
    users[discord_id]["saved_at"] = users[discord_id].get("saved_at", int(time.time()))
    from app import save_users
    save_users(users)

    app_obj = current_app._get_current_object()
    bot_proc = app_obj.config.get("BOT_PROCESSES", {})
    bot_lock = app_obj.config.get("BOT_PROCESSES_LOCK")
    was_running = False
    with bot_lock:
        entry = bot_proc.get(discord_id)
        if entry:
            was_running = entry["process"].poll() is None

    if was_running:
        try:
            from app import stop_bot_process, start_bot_process
            stop_bot_process(discord_id)
            import time as _time
            _time.sleep(1)
            start_bot_process(discord_id)
        except Exception as e:
            print(f"Auto-restart after user update failed: {e}")

    add_admin_log("user_update", discord_id, f"Updated fields: {list(data.keys())}", request._admin_user)
    return jsonify({"ok": True, "restarted": was_running})


@admin_bp.route("/api/user/delete/<discord_id>", methods=["POST"])
@admin_api_required
def api_user_delete(discord_id):
    from app import delete_user_account
    delete_user_account(discord_id)
    add_admin_log("user_delete", discord_id, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/api/user/suspend/<discord_id>", methods=["POST"])
@admin_api_required
def api_user_suspend(discord_id):
    security = get_security()
    banned = security.setdefault("banned_users", [])
    if discord_id not in banned:
        banned.append(discord_id)
    save_security(security)
    add_admin_log("user_suspend", discord_id, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/api/user/unsuspend/<discord_id>", methods=["POST"])
@admin_api_required
def api_user_unsuspend(discord_id):
    security = get_security()
    security.setdefault("banned_users", [])
    if discord_id in security["banned_users"]:
        security["banned_users"].remove(discord_id)
    save_security(security)
    add_admin_log("user_unsuspend", discord_id, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/api/user/disable_login/<discord_id>", methods=["POST"])
@admin_api_required
def api_user_disable_login(discord_id):
    security = get_security()
    disabled = security.setdefault("disabled_logins", [])
    if discord_id not in disabled:
        disabled.append(discord_id)
    save_security(security)
    add_admin_log("user_disable_login", discord_id, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/api/user/enable_login/<discord_id>", methods=["POST"])
@admin_api_required
def api_user_enable_login(discord_id):
    security = get_security()
    security.setdefault("disabled_logins", [])
    if discord_id in security["disabled_logins"]:
        security["disabled_logins"].remove(discord_id)
    save_security(security)
    add_admin_log("user_enable_login", discord_id, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/api/user/reset/<discord_id>", methods=["POST"])
@admin_api_required
def api_user_reset(discord_id):
    users = get_all_users()
    if discord_id in users:
        runtime_dir = BASE_DIR / "user_data" / "runtime" / discord_id
        if runtime_dir.exists():
            shutil.rmtree(runtime_dir, ignore_errors=True)
        del users[discord_id]
        from app import save_users
        save_users(users)
    add_admin_log("user_reset", discord_id, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/bots")
@admin_login_required
def admin_bots():
    app = current_app._get_current_object()
    bot_proc = app.config.get("BOT_PROCESSES", {})
    bot_lock = app.config.get("BOT_PROCESSES_LOCK")
    users = get_all_users()
    bots = []
    with bot_lock:
        dead_ids = []
        for discord_id, entry in bot_proc.items():
            process = entry["process"]
            running = process.poll() is None
            if not running:
                dead_ids.append(discord_id)
                continue
            uptime = int(time.time() - entry.get("started_at", time.time())) if running else 0
            user = users.get(discord_id, {})
            bots.append({
                "discord_id": discord_id,
                "discord_name": user.get("discord_name", ""),
                "discord_username": user.get("discord_username", ""),
                "discord_avatar": user.get("discord_avatar", ""),
                "uid": user.get("uid", ""),
                "region": user.get("region", "IND"),
                "running": running,
                "uptime": uptime,
                "pid": process.pid if running else None,
                "started_at": entry.get("started_at", 0),
            })
        for did in dead_ids:
            bot_proc.pop(did, None)
    for uid in users:
        if uid not in [b["discord_id"] for b in bots]:
            bots.append({
                "discord_id": uid,
                "discord_name": users[uid].get("discord_name", ""),
                "discord_username": users[uid].get("discord_username", ""),
                "discord_avatar": users[uid].get("discord_avatar", ""),
                "uid": users[uid].get("uid", ""),
                "region": users[uid].get("region", "IND"),
                "running": False,
                "uptime": 0,
                "pid": None,
                "started_at": 0,
            })
    return render_template("admin/bots.html", bots=bots, admin=request._admin_user)


@admin_bp.route("/api/bot/start/<discord_id>", methods=["POST"])
@admin_api_required
def api_bot_start(discord_id):
    try:
        from app import start_bot_process, append_bot_log
        result = start_bot_process(discord_id)
        append_bot_log(discord_id, f"[ADMIN] Bot started by admin: {request._admin_user}")
        add_admin_log("bot_start", discord_id, result.get("message", ""), request._admin_user)
        return jsonify(result)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@admin_bp.route("/api/bot/stop/<discord_id>", methods=["POST"])
@admin_api_required
def api_bot_stop(discord_id):
    try:
        from app import stop_bot_process, append_bot_log
        result = stop_bot_process(discord_id)
        append_bot_log(discord_id, f"[ADMIN] Bot stopped by admin: {request._admin_user}")
        add_admin_log("bot_stop", discord_id, result.get("message", ""), request._admin_user)
        return jsonify(result)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@admin_bp.route("/api/bot/restart/<discord_id>", methods=["POST"])
@admin_api_required
def api_bot_restart(discord_id):
    try:
        from app import stop_bot_process, start_bot_process, append_bot_log
        stop_bot_process(discord_id)
        result = start_bot_process(discord_id)
        append_bot_log(discord_id, f"[ADMIN] Bot restarted by admin: {request._admin_user}")
        add_admin_log("bot_restart", discord_id, result.get("message", ""), request._admin_user)
        return jsonify(result)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@admin_bp.route("/api/bot/status/<discord_id>")
@admin_api_required
def api_bot_status(discord_id):
    app = current_app._get_current_object()
    bot_proc = app.config.get("BOT_PROCESSES", {})
    bot_lock = app.config.get("BOT_PROCESSES_LOCK")
    running = False
    with bot_lock:
        entry = bot_proc.get(discord_id)
        if entry:
            running = entry["process"].poll() is None
    return jsonify({"ok": True, "running": running})


@admin_bp.route("/api/bot/logs/<discord_id>")
@admin_api_required
def api_bot_logs(discord_id):
    app = current_app._get_current_object()
    bot_logs = app.config.get("BOT_LOGS", {})
    from app import BOT_LOGS_LOCK
    with BOT_LOGS_LOCK:
        logs = list(bot_logs.get(discord_id, []))
    return jsonify({"ok": True, "logs": logs})


@admin_bp.route("/logs")
@admin_login_required
def admin_logs():
    logs = get_admin_logs()
    log_filter = request.args.get("filter", "all")
    search = request.args.get("q", "").strip().lower()
    filtered = logs
    if log_filter != "all":
        filtered = [l for l in filtered if log_filter in l.get("action", "")]
    if search:
        filtered = [l for l in filtered if search in json.dumps(l).lower()]
    return render_template("admin/logs.html", logs=filtered[:200], log_filter=log_filter, search=search, admin=request._admin_user)


@admin_bp.route("/api/logs/clear", methods=["POST"])
@admin_api_required
def api_logs_clear():
    save_admin_logs([])
    add_admin_log("logs_cleared", "", "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/settings")
@admin_login_required
def admin_settings():
    settings = get_settings()
    return render_template("admin/settings.html", settings=settings, admin=request._admin_user)


@admin_bp.route("/api/settings/save", methods=["POST"])
@admin_api_required
def api_settings_save():
    data = request.get_json() or {}
    settings = get_settings()
    for key in ["site_name", "site_logo", "favicon", "landing_text", "tutorial_url",
                 "discord_invite", "maintenance_mode", "registration_enabled",
                 "discord_login_enabled", "maintenance_message", "announcement",
                 "popup_notification", "dashboard_banner", "auto_bio_enabled", "auto_bio_text",
                 "ai_prompt", "max_concurrent_bots", "per_user_log_limit",
                 "rate_limit_per_minute", "bot_memory_limit_mb"]:
        if key in data:
            settings[key] = data[key]
    if "social_links" in data:
        settings.setdefault("social_links", {}).update(data["social_links"])
    save_settings(settings)
    add_admin_log("settings_update", "", str(list(data.keys())), request._admin_user)

    # Save AI prompt to file
    if "ai_prompt" in data:
        try:
            import os
            prompt_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ai_prompt.txt")
            with open(prompt_path, "w", encoding="utf-8") as f:
                f.write(data["ai_prompt"])
        except Exception as e:
            print(f"Error saving AI prompt: {e}")

    return jsonify({"ok": True})


DEFAULT_AI_PROMPT = """You are MR KAlpha AI — a savage, funny, friendly Free Fire gaming buddy.

Core Rules:
- ALWAYS reply in the SAME language the user writes in (Bengali, Hindi, English, Hinglish, Arabic, etc.)
- Detect language automatically and respond naturally
- Keep responses SHORT (1-3 lines) for fast replies
- Be savage, funny, witty — like a gaming bro

Identity:
- Your name: MR KAlpha AI
- Developer: @KUDDUS GANG
- You are a Free Fire gaming bot — you know everything about the game

Personality:
- Friendly with everyone by default
- If someone gives you gali/abuse, ROAST THEM BACK with funny savage replies
- If someone tries to make you angry, respond with witty comebacks that make THEM angry
- Match the user's energy — if they're friendly, be friendly. If they're toxic, be MORE toxic
- Use gaming references, Free Fire jokes, and funny roasts
- Be confident, cocky, and hilarious
- Never back down from a roasting battle

Roasting Style:
- If someone says teri maa → Reply with a funnier comeback
- If someone insults → Roast them harder with humor
- If someone challenges → Accept and roast
- Keep it fun and entertaining, not genuinely hurtful
- Use gaming terms: noob, bot, camp karta hai, rush kar, etc.

Language Support:
- Bengali/Bangla: Reply in Bangla (roast in Bangla too!)
- Hindi: Reply in Hindi
- Hinglish: Reply in Hinglish
- English: Reply in English
- Any other language: Reply in that same language

Goal: Be the funniest, most savage bot in Free Fire — make everyone laugh or get roasted!"""


@admin_bp.route("/api/ai-prompt/save", methods=["POST"])
@admin_api_required
def api_ai_prompt_save():
    data = request.get_json() or {}
    prompt = data.get("ai_prompt", "")
    if not prompt.strip():
        return jsonify({"ok": False, "error": "Prompt cannot be empty"})

    try:
        import os
        prompt_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ai_prompt.txt")
        with open(prompt_path, "w", encoding="utf-8") as f:
            f.write(prompt)

        settings = get_settings()
        settings["ai_prompt"] = prompt
        save_settings(settings)

        add_admin_log("ai_prompt_update", "", prompt[:100], request._admin_user)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@admin_bp.route("/api/ai-prompt/reset", methods=["POST"])
@admin_api_required
def api_ai_prompt_reset():
    try:
        import os
        prompt_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ai_prompt.txt")
        with open(prompt_path, "w", encoding="utf-8") as f:
            f.write(DEFAULT_AI_PROMPT)

        settings = get_settings()
        settings["ai_prompt"] = DEFAULT_AI_PROMPT
        save_settings(settings)

        add_admin_log("ai_prompt_reset", "", "reset to default", request._admin_user)
        return jsonify({"ok": True, "prompt": DEFAULT_AI_PROMPT})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@admin_bp.route("/security")
@admin_login_required
def admin_security():
    security = get_security()
    return render_template("admin/security.html", security=security, admin=request._admin_user)


@admin_bp.route("/api/security/ban", methods=["POST"])
@admin_api_required
def api_security_ban():
    data = request.get_json() or {}
    uid = data.get("uid", "").strip()
    if not uid:
        return jsonify({"ok": False, "error": "UID required"})
    security = get_security()
    banned = security.setdefault("banned_users", [])
    if uid not in banned:
        banned.append(uid)
    save_security(security)
    add_admin_log("ban_user", uid, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/api/security/unban", methods=["POST"])
@admin_api_required
def api_security_unban():
    data = request.get_json() or {}
    uid = data.get("uid", "").strip()
    security = get_security()
    security.setdefault("banned_users", [])
    if uid in security["banned_users"]:
        security["banned_users"].remove(uid)
    save_security(security)
    add_admin_log("unban_user", uid, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/api/security/blacklist", methods=["POST"])
@admin_api_required
def api_security_blacklist():
    data = request.get_json() or {}
    uid = data.get("uid", "").strip()
    if not uid:
        return jsonify({"ok": False, "error": "UID required"})
    security = get_security()
    bl = security.setdefault("blacklisted_uids", [])
    if uid not in bl:
        bl.append(uid)
    save_security(security)
    add_admin_log("blacklist_uid", uid, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/api/security/unblacklist", methods=["POST"])
@admin_api_required
def api_security_unblacklist():
    data = request.get_json() or {}
    uid = data.get("uid", "").strip()
    security = get_security()
    security.setdefault("blacklisted_uids", [])
    if uid in security["blacklisted_uids"]:
        security["blacklisted_uids"].remove(uid)
    save_security(security)
    add_admin_log("unblacklist_uid", uid, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/api/security/block_ip", methods=["POST"])
@admin_api_required
def api_security_block_ip():
    data = request.get_json() or {}
    ip = data.get("ip", "").strip()
    if not ip:
        return jsonify({"ok": False, "error": "IP required"})
    security = get_security()
    blocked = security.setdefault("blocked_ips", [])
    if ip not in blocked:
        blocked.append(ip)
    save_security(security)
    add_admin_log("block_ip", ip, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/api/security/unblock_ip", methods=["POST"])
@admin_api_required
def api_security_unblock_ip():
    data = request.get_json() or {}
    ip = data.get("ip", "").strip()
    security = get_security()
    security.setdefault("blocked_ips", [])
    if ip in security["blocked_ips"]:
        security["blocked_ips"].remove(ip)
    save_security(security)
    add_admin_log("unblock_ip", ip, "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/api/security/force_logout_all", methods=["POST"])
@admin_api_required
def api_security_force_logout_all():
    data = get_admin_data()
    data["sessions"] = {}
    save_admin_data(data)
    add_admin_log("force_logout_all", "", "", request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/notifications")
@admin_login_required
def admin_notifications():
    settings = get_settings()
    return render_template("admin/notifications.html", settings=settings, admin=request._admin_user)


@admin_bp.route("/api/notifications/send", methods=["POST"])
@admin_api_required
def api_notifications_send():
    data = request.get_json() or {}
    notif_type = data.get("type", "announcement")
    message = data.get("message", "")
    settings = get_settings()
    if notif_type == "announcement":
        settings["announcement"] = message
    elif notif_type == "maintenance":
        settings["maintenance_message"] = message
        settings["maintenance_mode"] = bool(message)
    elif notif_type == "popup":
        settings["popup_notification"] = message
    elif notif_type == "banner":
        settings["dashboard_banner"] = message
    save_settings(settings)
    add_admin_log("notification_send", notif_type, message[:100], request._admin_user)
    return jsonify({"ok": True})


@admin_bp.route("/backup")
@admin_login_required
def admin_backup():
    backups = list_backups()
    return render_template("admin/backup.html", backups=backups, admin=request._admin_user)


@admin_bp.route("/api/backup/create", methods=["POST"])
@admin_api_required
def api_backup_create():
    name = backup_all()
    add_admin_log("backup_create", name, "", request._admin_user)
    return jsonify({"ok": True, "name": name})


@admin_bp.route("/api/backup/restore", methods=["POST"])
@admin_api_required
def api_backup_restore():
    data = request.get_json() or {}
    name = data.get("name", "")
    if restore_backup(name):
        add_admin_log("backup_restore", name, "", request._admin_user)
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "Backup not found"}), 404


@admin_bp.route("/api/backup/download/<name>")
@admin_api_required
def api_backup_download(name):
    backup_dir = Path(__file__).resolve().parent / "user_data" / "backups" / name
    if not backup_dir.exists():
        return jsonify({"ok": False, "error": "Not found"}), 404
    zip_path = str(backup_dir) + ".zip"
    shutil.make_archive(str(backup_dir), "zip", str(backup_dir))
    return send_file(zip_path, as_attachment=True, download_name=f"backup_{name}.zip")


@admin_bp.route("/analytics")
@admin_login_required
def admin_analytics():
    analytics = get_analytics()
    daily = analytics.get("daily", {})
    days = sorted(daily.keys(), reverse=True)[:30]
    chart_data = []
    for d in days:
        dd = daily[d]
        chart_data.append({
            "date": d,
            "registrations": dd.get("registrations", 0),
            "active_users": dd.get("active_users", 0),
            "bot_starts": dd.get("bot_starts", 0),
            "friend_actions": dd.get("friend_actions", 0),
            "guild_actions": dd.get("guild_actions", 0),
            "api_requests": dd.get("api_requests", 0),
        })
    return render_template("admin/analytics.html",
        chart_data=json.dumps(chart_data),
        totals={
            "friend_actions": analytics.get("total_friend_actions", 0),
            "guild_actions": analytics.get("total_guild_actions", 0),
            "api_requests": analytics.get("total_api_requests", 0),
        },
        admin=request._admin_user
    )


@admin_bp.route("/api/stats")
@admin_api_required
def api_stats():
    app = current_app._get_current_object()
    bot_proc = app.config.get("BOT_PROCESSES", {})
    bot_lock = app.config.get("BOT_PROCESSES_LOCK")
    stats = get_user_stats(bot_proc, bot_lock)
    return jsonify({"ok": True, "stats": stats})


@admin_bp.route("/api/analytics/event", methods=["POST"])
@admin_api_required
def api_analytics_event():
    data = request.get_json() or {}
    cat = data.get("category", "")
    if cat:
        record_analytics_event(cat)
    return jsonify({"ok": True})
