import multiprocessing
import os

# Server socket
bind = os.environ.get("FLASK_HOST", "0.0.0.0") + ":" + os.environ.get("FLASK_PORT", "19138")

# Worker processes
workers = min(multiprocessing.cpu_count() * 2 + 1, 8)
worker_class = "gthread"
threads = 4
worker_timeout = 120

# Logging
accesslog = "-"
errorlog = "-"
loglevel = "info"

# Security
limit_request_line = 8190
limit_request_fields = 100

# Memory
max_requests = 500
max_requests_jitter = 50
