import asyncio
import io
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import re
from contextlib import contextmanager, redirect_stdout, redirect_stderr
from functools import wraps
from pathlib import Path
from typing import Any
from urllib.parse import urlencode
from dotenv import load_dotenv

import requests
from flask import Flask, jsonify, redirect, render_template, request, session, url_for
from admin_routes import admin_bp
from admin_db import ensure_admin_storage, record_analytics_event

BASE_DIR = Path(__file__).resolve().parent
USER_DATA_DIR = BASE_DIR / "user_data"
RUNTIME_DIR = USER_DATA_DIR / "runtime"
USERS_FILE = USER_DATA_DIR / "users.json"
TEMPLATES_AUTO_RELOAD = True
MAIN_MODULE = None

load_dotenv(BASE_DIR / ".env")


BOT_PROCESSES: dict[str, dict[str, Any]] = {}
BOT_PROCESSES_LOCK = threading.Lock()
BOT_LOGS: dict[str, list[str]] = {}
BOT_LOGS_LOCK = threading.Lock()
ACCOUNT_INFO_CACHE: dict[str, dict[str, Any]] = {}
ACCOUNT_INFO_LOCK = threading.Lock()
MAX_LOG_LINES = 400

# --- Performance: Rate Limiter ---
RATE_LIMIT_STORE: dict[str, list[float]] = {}
RATE_LIMIT_LOCK = threading.Lock()

def check_rate_limit(discord_id: str, limit: int = 30) -> bool:
    now = time.time()
    window = 60
    with RATE_LIMIT_LOCK:
        timestamps = RATE_LIMIT_STORE.setdefault(discord_id, [])
        timestamps[:] = [t for t in timestamps if now - t < window]
        if len(timestamps) >= limit:
            return False
        timestamps.append(now)
        return True

# --- Performance: Shared Event Loop ---
_SHARED_LOOP = None
_SHARED_LOOP_LOCK = threading.Lock()

def get_shared_loop():
    global _SHARED_LOOP
    with _SHARED_LOOP_LOCK:
        if _SHARED_LOOP is None or _SHARED_LOOP.is_closed():
            _SHARED_LOOP = asyncio.new_event_loop()
            threading.Thread(target=_SHARED_LOOP.run_forever, daemon=True).start()
        return _SHARED_LOOP

def run_async(coro):
    loop = get_shared_loop()
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return future.result(timeout=60)

# --- Performance: Dynamic settings ---
def get_perf_setting(key: str, default):
    try:
        from admin_db import get_settings
        return get_settings().get(key, default)
    except Exception:
        return default

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("FLASK_SECRET_KEY", "change-this-secret")
app.config["TEMPLATES_AUTO_RELOAD"] = TEMPLATES_AUTO_RELOAD
app.config["BOT_PROCESSES"] = BOT_PROCESSES
app.config["BOT_PROCESSES_LOCK"] = BOT_PROCESSES_LOCK
app.config["BOT_LOGS"] = BOT_LOGS
app.config["PERMANENT_SESSION_LIFETIME"] = 86400 * 30
app.config["SESSION_COOKIE_SECURE"] = False
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.register_blueprint(admin_bp)

import time as _time

@app.before_request
def make_session_permanent():
    session.permanent = True

@app.template_filter('timestamp_fmt')
def timestamp_fmt_filter(ts):
    try:
        return _time.strftime("%Y-%m-%d %H:%M", _time.localtime(int(ts)))
    except Exception:
        return str(ts)


DISCORD_CLIENT_ID = os.environ.get("DISCORD_CLIENT_ID", "")
DISCORD_CLIENT_SECRET = os.environ.get("DISCORD_CLIENT_SECRET", "")
DISCORD_REDIRECT_URI = os.environ.get(
    "DISCORD_REDIRECT_URI", "http://127.0.0.1:19200/auth/discord/callback"
)
DISCORD_API_BASE = "https://discord.com/api"
DISCORD_SCOPE = "identify email"

GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", "")
GOOGLE_REDIRECT_URI = os.environ.get(
    "GOOGLE_REDIRECT_URI", "http://127.0.0.1:19200/auth/google/callback"
)
GOOGLE_API_BASE = "https://oauth2.googleapis.com"
GOOGLE_SCOPE = "openid email profile"
FLASK_HOST = os.environ.get("FLASK_HOST", "127.0.0.1")
FLASK_PORT = int(os.environ.get("FLASK_PORT", "19200"))
SOCIAL_LINKS = {
    "youtube": os.environ.get("SOCIAL_YOUTUBE_URL", "#"),
    "discord": os.environ.get("SOCIAL_DISCORD_URL", "#"),
    "telegram": os.environ.get("SOCIAL_TELEGRAM_URL", "#"),
    "instagram": os.environ.get("SOCIAL_INSTAGRAM_URL", "#"),
}

RUNTIME_COPY_ITEMS = [
    "main.py",
    "KX.py",
    "autoup.py",
    "Pb2",
    "dev_generator_pb2.py",
    "devxt_count_pb2.py",
    "emotes.json",
    "item.py",
]


def get_main_module():
    global MAIN_MODULE
    if MAIN_MODULE is None:
        import importlib

        MAIN_MODULE = importlib.import_module("main")
    return MAIN_MODULE


def append_bot_log(discord_id: str, line: str) -> None:
    cleaned = line.rstrip()
    if not cleaned:
        return
    log_limit = get_perf_setting("per_user_log_limit", 150)
    with BOT_LOGS_LOCK:
        logs = BOT_LOGS.setdefault(discord_id, [])
        logs.append(cleaned)
        if len(logs) > log_limit:
            del logs[:-log_limit]
    update_account_info_from_log(discord_id, cleaned)


def get_bot_logs(discord_id: str) -> list[str]:
    with BOT_LOGS_LOCK:
        return list(BOT_LOGS.get(discord_id, []))


def clear_bot_logs(discord_id: str) -> None:
    with BOT_LOGS_LOCK:
        BOT_LOGS[discord_id] = []


def get_cached_account_info(discord_id: str) -> dict[str, Any]:
    with ACCOUNT_INFO_LOCK:
        return dict(ACCOUNT_INFO_CACHE.get(discord_id, {}))


def set_cached_account_info(discord_id: str, info: dict[str, Any]) -> None:
    with ACCOUNT_INFO_LOCK:
        current = ACCOUNT_INFO_CACHE.get(
            discord_id,
            {
                "name": "Unknown",
                "uid": "Unknown",
                "level": "Unknown",
                "region": "Unknown",
                "bio": "",
            },
        )
        for key, value in (info or {}).items():
            if value not in (None, "", "Unknown"):
                current[key] = value
        ACCOUNT_INFO_CACHE[discord_id] = current


def clear_cached_account_info(discord_id: str) -> None:
    with ACCOUNT_INFO_LOCK:
        ACCOUNT_INFO_CACHE.pop(discord_id, None)


def update_account_info_from_log(discord_id: str, line: str) -> None:
    clean_line = strip_game_formatting(line)
    if not clean_line:
        return

    parsed: dict[str, Any] = {}
    welcome_match = re.search(r"Welcome,\s*(.+?)!", clean_line, re.IGNORECASE)
    uid_match = re.search(r"Account UID:\s*([0-9]+)", clean_line, re.IGNORECASE)
    region_match = re.search(r"Region:\s*([A-Za-z0-9_-]+)", clean_line, re.IGNORECASE)
    level_match = re.search(r"Level:\s*([0-9]+)", clean_line, re.IGNORECASE)

    if welcome_match:
        parsed["name"] = welcome_match.group(1).strip()
    if uid_match:
        parsed["uid"] = uid_match.group(1).strip()
    if region_match:
        parsed["region"] = region_match.group(1).strip().upper()
    if level_match:
        parsed["level"] = level_match.group(1).strip()

    if parsed:
        set_cached_account_info(discord_id, parsed)


def stream_process_logs(discord_id: str, process: subprocess.Popen) -> None:
    if process.stdout is None:
        return

    try:
        for line in iter(process.stdout.readline, ""):
            if not line:
                break
            append_bot_log(discord_id, line)
        return_code = process.wait()
        append_bot_log(
            discord_id,
            f"[{time.strftime('%H:%M:%S')}] Bot process exited with code {return_code}.",
        )
        if return_code not in (0, None):
            append_bot_log(
                discord_id,
                f"[{time.strftime('%H:%M:%S')}] Auto-restarting bot due to unexpected exit (code {return_code})...",
            )
            threading.Thread(
                target=_auto_restart_bot,
                args=(discord_id,),
                daemon=True,
            ).start()
    finally:
        if process.stdout:
            process.stdout.close()


_AUTO_RESTART_DELAY = 10


def _auto_restart_bot(discord_id: str) -> None:
    time.sleep(_AUTO_RESTART_DELAY)
    try:
        record = load_users().get(discord_id)
        if not record:
            append_bot_log(discord_id, f"[{time.strftime('%H:%M:%S')}] Auto-restart skipped: no saved account.")
            return
        with BOT_PROCESSES_LOCK:
            existing = BOT_PROCESSES.get(discord_id)
            if existing and existing["process"].poll() is None:
                append_bot_log(discord_id, f"[{time.strftime('%H:%M:%S')}] Auto-restart skipped: bot already running.")
                return
        result = start_bot_process(discord_id)
        append_bot_log(
            discord_id,
            f"[{time.strftime('%H:%M:%S')}] Auto-restart result: {result.get('message', 'unknown')}",
        )
    except Exception as e:
        append_bot_log(
            discord_id,
            f"[{time.strftime('%H:%M:%S')}] Auto-restart failed: {e}",
        )


def ensure_storage() -> None:
    USER_DATA_DIR.mkdir(exist_ok=True)
    RUNTIME_DIR.mkdir(exist_ok=True)
    if not USERS_FILE.exists():
        USERS_FILE.write_text("{}", encoding="utf-8")


def load_users() -> dict[str, Any]:
    ensure_storage()
    try:
        return json.loads(USERS_FILE.read_text(encoding="utf-8") or "{}")
    except json.JSONDecodeError:
        return {}


def save_users(data: dict[str, Any]) -> None:
    ensure_storage()
    USERS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def current_discord_id() -> str | None:
    user = session.get("discord_user") or session.get("google_user")
    if not user:
        return None
    return str(user.get("id"))


def get_current_user_record() -> dict[str, Any] | None:
    discord_id = current_discord_id()
    if not discord_id:
        return None
    return load_users().get(discord_id)


def delete_user_account(discord_id: str) -> None:
    users = load_users()
    users.pop(discord_id, None)
    save_users(users)

    runtime_dir = user_runtime_dir(discord_id)
    if runtime_dir.exists():
        shutil.rmtree(runtime_dir, ignore_errors=True)


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "discord_user" not in session and "google_user" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped


def api_login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "discord_user" not in session and "google_user" not in session:
            return jsonify({"ok": False, "error": "Authentication required"}), 401
        return view(*args, **kwargs)

    return wrapped


def rate_limited_api(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        discord_id = current_discord_id()
        if discord_id:
            limit = get_perf_setting("rate_limit_per_minute", 30)
            if not check_rate_limit(discord_id, limit):
                return jsonify({"ok": False, "error": f"Rate limit exceeded. Max {limit} requests per minute."}), 429
        return view(*args, **kwargs)

    return wrapped


@app.context_processor
def inject_social_links():
    settings = {}
    try:
        from admin_db import get_settings
        settings = get_settings()
    except Exception:
        pass
    return {
        "social_links": settings.get("social_links", SOCIAL_LINKS),
        "site_settings": settings,
    }


def discord_login_url() -> str:
    params = {
        "client_id": DISCORD_CLIENT_ID,
        "redirect_uri": DISCORD_REDIRECT_URI,
        "response_type": "code",
        "scope": DISCORD_SCOPE,
        "prompt": "consent",
    }
    return f"{DISCORD_API_BASE}/oauth2/authorize?{urlencode(params)}"


def exchange_discord_code(code: str) -> dict[str, Any]:
    payload = {
        "client_id": DISCORD_CLIENT_ID,
        "client_secret": DISCORD_CLIENT_SECRET,
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": DISCORD_REDIRECT_URI,
    }
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    response = requests.post(
        f"{DISCORD_API_BASE}/oauth2/token", data=payload, headers=headers, timeout=30
    )
    response.raise_for_status()
    return response.json()


def fetch_discord_user(access_token: str) -> dict[str, Any]:
    response = requests.get(
        f"{DISCORD_API_BASE}/users/@me",
        headers={"Authorization": f"Bearer {access_token}"},
        timeout=30,
    )
    response.raise_for_status()
    return response.json()


def google_login_url() -> str:
    params = {
        "client_id": GOOGLE_CLIENT_ID,
        "redirect_uri": GOOGLE_REDIRECT_URI,
        "response_type": "code",
        "scope": GOOGLE_SCOPE,
        "access_type": "offline",
        "prompt": "consent",
    }
    return f"https://accounts.google.com/o/oauth2/v2/auth?{urlencode(params)}"


def exchange_google_code(code: str) -> dict[str, Any]:
    payload = {
        "client_id": GOOGLE_CLIENT_ID,
        "client_secret": GOOGLE_CLIENT_SECRET,
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": GOOGLE_REDIRECT_URI,
    }
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    response = requests.post(
        f"{GOOGLE_API_BASE}/token", data=payload, headers=headers, timeout=30
    )
    response.raise_for_status()
    return response.json()


def fetch_google_user(access_token: str) -> dict[str, Any]:
    response = requests.get(
        "https://www.googleapis.com/oauth2/v3/userinfo",
        headers={"Authorization": f"Bearer {access_token}"},
        timeout=30,
    )
    response.raise_for_status()
    return response.json()


def detect_login_mode(payload: dict[str, str]) -> tuple[str, str]:
    token = (payload.get("access_token") or "").strip()
    password = (payload.get("password") or "").strip()
    if token:
        return "direct", token
    if password:
        return "accs", password
    raise ValueError("Provide either a password or an access token.")


def sanitize_region(region: str) -> str:
    value = (region or "IND").strip().upper()
    return value or "IND"


def sanitize_device(device: str) -> int:
    return 2 if (device or "").strip().lower() == "pc" else 1


def user_runtime_dir(discord_id: str) -> Path:
    path = RUNTIME_DIR / discord_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def user_runtime_files(discord_id: str) -> dict[str, Path]:
    runtime = user_runtime_dir(discord_id)
    return {
        "dir": runtime,
        "accs": runtime / "accs.txt",
        "direct": runtime / "direct.txt",
        "token": runtime / "token.json",
        "cache": runtime / "status_cache.pkl",
        "config": runtime / "bot_config.json",
    }


def build_runtime_payload(record: dict[str, Any]) -> dict[str, Any]:
    device = record.get("device", "Phone")
    region = sanitize_region(record.get("region", "IND"))
    login_method, secret = detect_login_mode(record)
    owner_uid = str(record.get("owner_uid", "")).strip()
    return {
        "login_method": login_method,
        "login_type": sanitize_device(device),
        "region": region,
        "secret": secret,
        "owner_uid": owner_uid,
    }


def write_runtime_files(discord_id: str, record: dict[str, Any]) -> dict[str, Path]:
    files = user_runtime_files(discord_id)
    payload = build_runtime_payload(record)

    from admin_db import get_settings
    site_settings = get_settings()

    files["config"].write_text(
        json.dumps(
            {
                "login_method": payload["login_method"],
                "login_type": payload["login_type"],
                "region": payload["region"],
                "owner_uid": payload["owner_uid"],
                "auto_bio_enabled": site_settings.get("auto_bio_enabled", False),
                "auto_bio_text": site_settings.get("auto_bio_text", ""),
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    uid = str(record.get("uid", "")).strip()
    if payload["login_method"] == "direct":
        files["direct"].write_text(payload["secret"], encoding="utf-8")
        files["accs"].write_text("", encoding="utf-8")
    else:
        files["accs"].write_text(json.dumps({uid: payload["secret"]}), encoding="utf-8")
        files["direct"].write_text("", encoding="utf-8")

    return files


def parse_player_messages(messages: list[str], fallback_uid: str = "", fallback_region: str = "") -> dict[str, Any]:
    cleaned = strip_game_formatting("\n".join(messages or []))

    def extract(pattern: str, default: str = "Unknown") -> str:
        match = re.search(pattern, cleaned, re.IGNORECASE)
        return match.group(1).strip() if match else default

    return {
        "name": extract(r"Name:\s*(.+?)(?:UID:|Level:|Likes:|Bio:|Created:|Last Login:|$)"),
        "uid": extract(r"UID:\s*([0-9]+)", fallback_uid or "Unknown"),
        "level": extract(r"Level:\s*([0-9]+)", "Unknown"),
        "bio": extract(r"Bio:\s*(.+?)(?:Created:|Last Login:|Title:|Br Rank:|Cs Rank:|Likes:|Honor Score:|$)", ""),
        "region": fallback_region or "Unknown",
    }


def build_main_patch_code(owner_uid: str) -> str:
    safe_owner = json.dumps(owner_uid or "")
    return (
        "from pathlib import Path\n"
        "path = Path('main.py')\n"
        "text = path.read_text(encoding='utf-8')\n"
        f"owner = {safe_owner}\n"
        "if owner:\n"
        "    import re\n"
        "    text = re.sub(r'OWNER_UID\\s*=\\s*\"[^\"]*\"', f'OWNER_UID = \"{owner}\"', text, count=1)\n"
        "    text = re.sub(r'WHITELISTED_UIDS\\s*=\\s*\\{\\s*OWNER_UID,\\s*\\}', 'WHITELISTED_UIDS = {\\n    OWNER_UID,\\n}', text, count=1, flags=re.S)\n"
        "path.write_text(text, encoding='utf-8')\n"
    )


def prepare_runtime_workspace(runtime_dir: Path) -> None:
    runtime_dir.mkdir(parents=True, exist_ok=True)
    for item in RUNTIME_COPY_ITEMS:
        src = BASE_DIR / item
        dst = runtime_dir / item
        if not src.exists():
            continue
        if src.is_dir():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)


@contextmanager
def bot_file_context(discord_id: str, record: dict[str, Any]):
    main_module = get_main_module()
    files = write_runtime_files(discord_id, record)
    originals = {
        "config": main_module.CONFIG_FILE,
        "cache": getattr(main_module, "CACHE_FILE", "status_cache.pkl"),
    }

    original_cwd = Path.cwd()
    old_login_method = getattr(main_module, "LOGIN_METHOD", None)
    old_login_type = getattr(main_module, "LOGIN_TYPE", None)
    old_owner_uid = getattr(main_module, "OWNER_UID", None)
    old_whitelisted_uids = set(getattr(main_module, "WHITELISTED_UIDS", set()))

    runtime_payload = build_runtime_payload(record)

    main_module.CONFIG_FILE = str(files["config"])
    main_module.CACHE_FILE = str(files["cache"])
    main_module.LOGIN_METHOD = runtime_payload["login_method"]
    main_module.LOGIN_TYPE = runtime_payload["login_type"]
    if runtime_payload["owner_uid"]:
        main_module.OWNER_UID = runtime_payload["owner_uid"]
        main_module.WHITELISTED_UIDS = set(old_whitelisted_uids)
        main_module.WHITELISTED_UIDS.add(runtime_payload["owner_uid"])

    os.chdir(files["dir"])
    try:
        yield files
    finally:
        os.chdir(original_cwd)
        main_module.CONFIG_FILE = originals["config"]
        main_module.CACHE_FILE = originals["cache"]
        main_module.LOGIN_METHOD = old_login_method
        main_module.LOGIN_TYPE = old_login_type
        main_module.OWNER_UID = old_owner_uid
        main_module.WHITELISTED_UIDS = old_whitelisted_uids


def strip_game_formatting(text: str) -> str:
    if text is None:
        return ""
    cleaned = str(text)
    for token in ("[B]", "[C]"):
        cleaned = cleaned.replace(token, "")
    while "[" in cleaned and "]" in cleaned:
        start = cleaned.find("[")
        end = cleaned.find("]", start)
        if end == -1:
            break
        cleaned = cleaned[:start] + cleaned[end + 1 :]
    return " ".join(cleaned.split())


def runtime_token_info(discord_id: str) -> dict[str, Any] | None:
    files = user_runtime_files(discord_id)
    token_file = files["token"]
    if not token_file.exists():
        return None
    try:
        return json.loads(token_file.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


# NOTE: run_async is now defined at the top of the file using shared event loop

def fetch_player_info_for_user(
    main_module,
    token: str,
    region: str,
    target_uid: str,
    fallback_region: str = "",
) -> dict[str, Any]:
    info_messages = run_async(main_module.GeT_PLayer_InFo(target_uid, token, region))
    return parse_player_messages(
        info_messages if isinstance(info_messages, list) else [],
        fallback_uid=target_uid,
        fallback_region=fallback_region or region,
    )


def dedupe_friends_by_uid(friends: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    deduped: list[dict[str, Any]] = []

    for friend in friends or []:
        uid = str(friend.get("uid", "")).strip()
        if not uid:
            deduped.append(friend)
            continue
        if uid in seen:
            continue
        seen.add(uid)
        deduped.append(friend)

    return deduped


def call_action_with_user(discord_id: str, action_name: str, **kwargs) -> dict[str, Any]:
    main_module = get_main_module()
    record = load_users().get(discord_id)
    if not record:
        raise ValueError("No saved game account found for this Discord user.")

    token_info = runtime_token_info(discord_id)
    if not token_info or not token_info.get("token"):
        raise ValueError("No active token found. Start the bot first to create a session token.")

    token = token_info["token"]
    region = sanitize_region(record.get("region", token_info.get("region", "IND")))
    stdout_buffer = io.StringIO()

    with bot_file_context(discord_id, record), redirect_stdout(stdout_buffer), redirect_stderr(stdout_buffer):
        if action_name == "add_friend":
            raw = run_async(main_module.RequestAddingFriend_Uid_async(kwargs["target_uid"], token, region))
        elif action_name == "remove_friend":
            raw = main_module.DeLet_Uid(kwargs["target_uid"], token, region)
        elif action_name == "join_guild":
            raw = run_async(main_module.RequestJoinClan(kwargs["guild_id"], token, region))
        elif action_name == "leave_guild":
            raw = run_async(main_module.QuitClan(kwargs["guild_id"], token, region))
        elif action_name == "friend_list":
            cache_key = f"{region}_{token}"
            try:
                async def clear_friend_cache():
                    async with main_module.friend_cache_lock:
                        main_module.friend_cache.pop(cache_key, None)
                run_async(clear_friend_cache())
            except Exception:
                pass
            raw = run_async(main_module.get_friend_list(token, region))
        else:
            raise ValueError(f"Unsupported action: {action_name}")

    result: dict[str, Any] = {
        "ok": True,
        "action": action_name,
        "logs": stdout_buffer.getvalue().strip(),
    }
    if action_name == "friend_list":
        if isinstance(raw, dict):
            friends = dedupe_friends_by_uid(raw.get("Friends", []))
            enriched_friends = []
            seen_enriched: set[str] = set()
            for friend in friends:
                friend_uid = str(friend.get("uid", "")).strip()
                if friend_uid and friend_uid in seen_enriched:
                    continue
                if friend_uid:
                    seen_enriched.add(friend_uid)
                parsed = {
                    "uid": friend_uid,
                    "name": friend.get("name", "Unknown"),
                    "level": "Unknown",
                    "bio": "",
                    "region": region,
                }
                if friend_uid:
                    try:
                        parsed = fetch_player_info_for_user(
                            main_module, token, region, friend_uid, fallback_region=region
                        )
                    except Exception:
                        pass
                enriched_friends.append(parsed)
            raw["Friends"] = enriched_friends
        result["data"] = raw.get("Friends", []) if isinstance(raw, dict) else []
        result["message"] = "Friend list loaded."
    else:
        result["raw"] = raw
        result["message"] = strip_game_formatting(raw)
        info_uid = ""
        if action_name in {"add_friend", "remove_friend"}:
            info_uid = str(kwargs.get("target_uid", "")).strip()
        elif action_name in {"join_guild", "leave_guild"}:
            info_uid = str(record.get("uid") or token_info.get("bot_uid") or "").strip()

        if info_uid:
            try:
                result["player"] = fetch_player_info_for_user(
                    main_module,
                    token,
                    region,
                    info_uid,
                    fallback_region=region,
                )
                if action_name == "add_friend":
                    result["message"] = f"Friend Added: {result['player'].get('name', 'Unknown')}"
                elif action_name == "remove_friend":
                    result["message"] = f"Friend Removed: {result['player'].get('name', 'Unknown')}"
                elif action_name == "join_guild":
                    result["message"] = f"Guild Joined: {result['player'].get('name', 'Unknown')}"
                elif action_name == "leave_guild":
                    result["message"] = f"Guild Left: {result['player'].get('name', 'Unknown')}"
            except Exception:
                pass
    return result


def fetch_account_info(discord_id: str) -> dict[str, Any]:
    cached = get_cached_account_info(discord_id)
    if any(cached.get(key) not in (None, "", "Unknown") for key in ("name", "uid", "level", "region", "bio")):
        return cached

    main_module = get_main_module()
    record = load_users().get(discord_id)
    if not record:
        raise ValueError("No saved game account found for this Discord user.")

    token_info = runtime_token_info(discord_id)
    if not token_info or not token_info.get("token"):
        raise ValueError("No active token found. Start the bot first to fetch account info.")

    token = token_info["token"]
    region = sanitize_region(record.get("region", token_info.get("region", "IND")))
    uid = str(record.get("uid") or token_info.get("bot_uid") or "").strip()
    if not uid:
        raise ValueError("No UID available to fetch account info.")

    with bot_file_context(discord_id, record):
        info = run_async(main_module.GeT_PLayer_InFo(uid, token, region))

    parsed = parse_player_messages(info if isinstance(info, list) else [], fallback_uid=uid, fallback_region=region)
    set_cached_account_info(discord_id, parsed)
    return parsed


def start_bot_process(discord_id: str) -> dict[str, Any]:
    users = load_users()
    record = users.get(discord_id)
    if not record:
        raise ValueError("Save your game account first.")

    max_bots = get_perf_setting("max_concurrent_bots", 50)
    with BOT_PROCESSES_LOCK:
        running_count = sum(1 for p in BOT_PROCESSES.values() if p["process"].poll() is None)
        existing = BOT_PROCESSES.get(discord_id)
        if existing:
            if existing["process"].poll() is None:
                return {"ok": True, "message": "Bot is already running."}
            else:
                BOT_PROCESSES.pop(discord_id, None)
        if running_count >= max_bots:
            raise ValueError(f"Max concurrent bot limit reached ({max_bots}). Stop other bots first.")

    files = write_runtime_files(discord_id, record)
    runtime_payload = build_runtime_payload(record)
    prepare_runtime_workspace(files["dir"])
    patch_script = build_main_patch_code(runtime_payload["owner_uid"]) if runtime_payload["owner_uid"] else ""

    with BOT_PROCESSES_LOCK:
        existing = BOT_PROCESSES.get(discord_id)
        if existing and existing["process"].poll() is None:
            return {"ok": True, "message": "Bot is already running."}

        clear_bot_logs(discord_id)
        clear_cached_account_info(discord_id)
        append_bot_log(discord_id, f"[{time.strftime('%H:%M:%S')}] Starting bot process...")
        env = os.environ.copy()
        existing_pythonpath = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = (
            str(BASE_DIR) if not existing_pythonpath else f"{str(BASE_DIR)}{os.pathsep}{existing_pythonpath}"
        )
        if patch_script:
            patch_process = subprocess.run(
                [sys.executable, "-c", patch_script],
                cwd=str(files["dir"]),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            if patch_process.stdout.strip():
                append_bot_log(discord_id, patch_process.stdout.strip())
            if patch_process.stderr.strip():
                append_bot_log(discord_id, patch_process.stderr.strip())
            if patch_process.returncode != 0:
                raise ValueError("Failed to prepare runtime main.py with owner UID.")
            command = [sys.executable, "-u", str(files["dir"] / "main.py")]
        else:
            command = [sys.executable, "-u", str(BASE_DIR / "main.py")]
        append_bot_log(discord_id, f"[{time.strftime('%H:%M:%S')}] Command: {' '.join(command)}")
        append_bot_log(discord_id, f"[{time.strftime('%H:%M:%S')}] Runtime directory: {files['dir']}")
        append_bot_log(discord_id, f"[{time.strftime('%H:%M:%S')}] PYTHONPATH: {env['PYTHONPATH']}")

        mem_limit_mb = get_perf_setting("bot_memory_limit_mb", 256)
        preexec_fn = None
        if sys.platform != "win32":
            import resource
            def _set_limits():
                mem_bytes = mem_limit_mb * 1024 * 1024
                resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
            preexec_fn = _set_limits

        process = subprocess.Popen(
            command,
            cwd=str(files["dir"]),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            env=env,
            preexec_fn=preexec_fn,
        )
        append_bot_log(discord_id, f"[{time.strftime('%H:%M:%S')}] Bot process started.")
        log_thread = threading.Thread(
            target=stream_process_logs, args=(discord_id, process), daemon=True
        )
        log_thread.start()
        BOT_PROCESSES[discord_id] = {
            "process": process,
            "started_at": time.time(),
            "log_thread": log_thread,
        }
    return {"ok": True, "message": "Bot started successfully."}


def stop_bot_process(discord_id: str) -> dict[str, Any]:
    with BOT_PROCESSES_LOCK:
        entry = BOT_PROCESSES.get(discord_id)
        if not entry:
            return {"ok": True, "message": "Bot is already stopped."}

        process: subprocess.Popen = entry["process"]
        if process.poll() is None:
            append_bot_log(discord_id, f"[{time.strftime('%H:%M:%S')}] Stopping bot process...")
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                append_bot_log(discord_id, f"[{time.strftime('%H:%M:%S')}] Bot did not stop in time, killing process...")
                process.kill()
                process.wait(timeout=5)
        BOT_PROCESSES.pop(discord_id, None)
    clear_cached_account_info(discord_id)
    append_bot_log(discord_id, f"[{time.strftime('%H:%M:%S')}] Bot stopped.")
    return {"ok": True, "message": "Bot stopped successfully."}


def bot_status(discord_id: str) -> dict[str, Any]:
    with BOT_PROCESSES_LOCK:
        entry = BOT_PROCESSES.get(discord_id)
        if not entry:
            return {"running": False, "status": "Stopped"}

        process: subprocess.Popen = entry["process"]
        running = process.poll() is None
        if not running:
            BOT_PROCESSES.pop(discord_id, None)
            return {"running": False, "status": "Stopped"}

        started_at = entry.get("started_at")
        uptime = int(time.time() - started_at) if started_at else 0
        return {"running": True, "status": "Running", "uptime_seconds": uptime}


@app.route("/")
def index():
    return render_template(
        "index.html",
        discord_login_url=discord_login_url(),
        discord_configured=bool(DISCORD_CLIENT_ID and DISCORD_CLIENT_SECRET),
        google_login_url=google_login_url(),
        google_configured=bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET),
        user=session.get("discord_user") or session.get("google_user"),
    )


@app.route("/login")
def login():
    if "discord_user" in session or "google_user" in session:
        return redirect(url_for("dashboard"))
    return render_template(
        "login.html",
        discord_login_url=discord_login_url(),
        discord_configured=bool(DISCORD_CLIENT_ID and DISCORD_CLIENT_SECRET),
        google_login_url=google_login_url(),
        google_configured=bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET),
    )


@app.route("/auth/discord")
def auth_discord():
    if not DISCORD_CLIENT_ID or not DISCORD_CLIENT_SECRET:
        return redirect(url_for("login", error="discord_not_configured"))
    return redirect(discord_login_url())


@app.route("/auth/google")
def auth_google():
    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
        return redirect(url_for("login", error="google_not_configured"))
    return redirect(google_login_url())


@app.route("/auth/discord/callback")
@app.route("/discord/callback")
def discord_callback():
    error = request.args.get("error")
    if error:
        return redirect(url_for("login", error=error))

    code = request.args.get("code")
    if not code:
        return redirect(url_for("login", error="missing_code"))

    try:
        token_payload = exchange_discord_code(code)
        user = fetch_discord_user(token_payload["access_token"])
    except Exception:
        return redirect(url_for("login", error="oauth_failed"))

    session["discord_user"] = {
        "id": user["id"],
        "username": user.get("username"),
        "global_name": user.get("global_name"),
        "avatar": user.get("avatar"),
        "email": user.get("email"),
        "provider": "discord",
    }

    users = load_users()
    discord_id = str(user["id"])
    if discord_id not in users:
        users[discord_id] = {}
    users[discord_id]["discord_name"] = user.get("global_name") or user.get("username", "")
    users[discord_id]["discord_username"] = user.get("username", "")
    users[discord_id]["discord_avatar"] = user.get("avatar", "")
    save_users(users)

    return redirect(url_for("dashboard"))


@app.route("/auth/google/callback")
def google_callback():
    error = request.args.get("error")
    if error:
        return redirect(url_for("login", error=error))

    code = request.args.get("code")
    if not code:
        return redirect(url_for("login", error="missing_code"))

    try:
        token_payload = exchange_google_code(code)
        user = fetch_google_user(token_payload["access_token"])
    except Exception:
        return redirect(url_for("login", error="oauth_failed"))

    google_id = user.get("sub", "")
    session["google_user"] = {
        "id": google_id,
        "username": user.get("email", ""),
        "global_name": user.get("name", ""),
        "avatar": user.get("picture", ""),
        "email": user.get("email", ""),
        "provider": "google",
    }

    users = load_users()
    if google_id not in users:
        users[google_id] = {}
    users[google_id]["google_name"] = user.get("name", "")
    users[google_id]["google_email"] = user.get("email", "")
    users[google_id]["google_avatar"] = user.get("picture", "")
    save_users(users)

    return redirect(url_for("dashboard"))


@app.route("/logout")
def logout():
    discord_id = current_discord_id()
    if discord_id:
        stop_bot_process(discord_id)
    session.clear()
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required
def dashboard():
    discord_id = current_discord_id()
    record = get_current_user_record() or {}
    token_info = runtime_token_info(discord_id) if discord_id else None
    has_game_account = bool(record.get("uid") or record.get("access_token"))
    edit_mode = request.args.get("edit") == "1" or not has_game_account
    user = session.get("discord_user") or session.get("google_user")
    return render_template(
        "dashboard.html",
        user=user,
        account=record,
        bot_status=bot_status(discord_id) if discord_id else {"running": False, "status": "Stopped"},
        token_info=token_info,
        edit_mode=edit_mode,
    )


@app.route("/tools")
@login_required
def tools():
    discord_id = current_discord_id()
    return render_template(
        "tools.html",
        user=session.get("discord_user") or session.get("google_user"),
        account=get_current_user_record() or {},
        bot_status=bot_status(discord_id) if discord_id else {"running": False, "status": "Stopped"},
    )


@app.route("/account", methods=["POST"])
@login_required
def save_account():
    discord_id = current_discord_id()
    payload = {
        "uid": request.form.get("uid", "").strip(),
        "password": request.form.get("password", "").strip(),
        "access_token": request.form.get("access_token", "").strip(),
        "device": request.form.get("device", "Phone").strip(),
        "owner_uid": request.form.get("owner_uid", "").strip(),
        "region": sanitize_region(request.form.get("region", "IND")),
        "saved_at": int(time.time()),
    }

    try:
        detect_login_mode(payload)
    except ValueError as exc:
        return redirect(url_for("dashboard", error=str(exc)))

    users = load_users()
    existing = users.get(discord_id, {})
    existing.update(payload)
    users[discord_id] = existing
    save_users(users)
    return redirect(url_for("dashboard", saved="1"))


@app.route("/account/delete", methods=["POST"])
@login_required
def delete_account_route():
    discord_id = current_discord_id()
    stop_bot_process(discord_id)
    delete_user_account(discord_id)
    return redirect(url_for("dashboard", deleted="1"))


@app.route("/api/status")
@app.route("/api/get_status")
@api_login_required
def api_status():
    discord_id = current_discord_id()
    return jsonify(
        {
            "ok": True,
            "bot": bot_status(discord_id),
            "account": get_current_user_record(),
            "token_info": runtime_token_info(discord_id),
            "logs": get_bot_logs(discord_id),
        }
    )


@app.route("/api/account_info")
@api_login_required
def api_account_info():
    discord_id = current_discord_id()
    try:
        return jsonify({"ok": True, "account_info": fetch_account_info(discord_id)})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/player_info", methods=["POST"])
@api_login_required
@rate_limited_api
def api_player_info():
    discord_id = current_discord_id()
    target_uid = request.json.get("target_uid", "").strip() if request.is_json else request.form.get("target_uid", "").strip()
    if not target_uid:
        return jsonify({"ok": False, "error": "Target UID is required."}), 400

    record = load_users().get(discord_id)
    if not record:
        return jsonify({"ok": False, "error": "No saved game account found."}), 400

    token_info = runtime_token_info(discord_id)
    if not token_info or not token_info.get("token"):
        return jsonify({"ok": False, "error": "No active token found. Start the bot first."}), 400

    token = token_info["token"]
    region = sanitize_region(record.get("region", token_info.get("region", "IND")))
    main_module = get_main_module()

    try:
        with bot_file_context(discord_id, record):
            parsed = fetch_player_info_for_user(
                main_module, token, region, target_uid, fallback_region=region
            )
        return jsonify({"ok": True, "player_info": parsed})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/logs")
@api_login_required
def api_logs():
    discord_id = current_discord_id()
    return jsonify(
        {
            "ok": True,
            "bot": bot_status(discord_id),
            "logs": get_bot_logs(discord_id),
        }
    )


@app.route("/api/start_bot", methods=["POST"])
@api_login_required
@rate_limited_api
def api_start_bot():
    discord_id = current_discord_id()
    try:
        result = start_bot_process(discord_id)
        try: record_analytics_event("bot_starts")
        except Exception: pass
        return jsonify(result)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/stop_bot", methods=["POST"])
@api_login_required
@rate_limited_api
def api_stop_bot():
    discord_id = current_discord_id()
    try:
        result = stop_bot_process(discord_id)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/restart_bot", methods=["POST"])
@api_login_required
@rate_limited_api
def api_restart_bot():
    discord_id = current_discord_id()
    try:
        stop_bot_process(discord_id)
        result = start_bot_process(discord_id)
        result["message"] = "Bot restarted successfully."
        return jsonify(result)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/add_friend", methods=["POST"])
@api_login_required
@rate_limited_api
def api_add_friend():
    discord_id = current_discord_id()
    target_uid = request.json.get("target_uid", "").strip() if request.is_json else request.form.get("target_uid", "").strip()
    if not target_uid:
        return jsonify({"ok": False, "error": "Target UID is required."}), 400
    try:
        result = call_action_with_user(discord_id, "add_friend", target_uid=target_uid)
        try: record_analytics_event("friend_actions")
        except Exception: pass
        return jsonify(result)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/remove_friend", methods=["POST"])
@api_login_required
@rate_limited_api
def api_remove_friend():
    discord_id = current_discord_id()
    target_uid = request.json.get("target_uid", "").strip() if request.is_json else request.form.get("target_uid", "").strip()
    if not target_uid:
        return jsonify({"ok": False, "error": "Target UID is required."}), 400
    try:
        result = call_action_with_user(discord_id, "remove_friend", target_uid=target_uid)
        try: record_analytics_event("friend_actions")
        except Exception: pass
        return jsonify(result)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/join_guild", methods=["POST"])
@api_login_required
@rate_limited_api
def api_join_guild():
    discord_id = current_discord_id()
    guild_id = request.json.get("guild_id", "").strip() if request.is_json else request.form.get("guild_id", "").strip()
    if not guild_id:
        return jsonify({"ok": False, "error": "Guild ID is required."}), 400
    try:
        result = call_action_with_user(discord_id, "join_guild", guild_id=guild_id)
        try: record_analytics_event("guild_actions")
        except Exception: pass
        return jsonify(result)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/leave_guild", methods=["POST"])
@api_login_required
@rate_limited_api
def api_leave_guild():
    discord_id = current_discord_id()
    guild_id = request.json.get("guild_id", "").strip() if request.is_json else request.form.get("guild_id", "").strip()
    if not guild_id:
        return jsonify({"ok": False, "error": "Guild ID is required."}), 400
    try:
        result = call_action_with_user(discord_id, "leave_guild", guild_id=guild_id)
        try: record_analytics_event("guild_actions")
        except Exception: pass
        return jsonify(result)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.route("/api/friend_list", methods=["GET"])
@api_login_required
@rate_limited_api
def api_friend_list():
    discord_id = current_discord_id()
    try:
        return jsonify(call_action_with_user(discord_id, "friend_list"))
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


if __name__ == "__main__":
    ensure_storage()
    ensure_admin_storage()
    app.run(host=FLASK_HOST, port=FLASK_PORT, debug=True)
