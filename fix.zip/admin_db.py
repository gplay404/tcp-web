import json
import time
import os
import hashlib
import secrets
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent
ADMIN_DB = BASE_DIR / "user_data" / "admin.json"
SETTINGS_DB = BASE_DIR / "user_data" / "settings.json"
ADMIN_LOGS_DB = BASE_DIR / "user_data" / "admin_logs.json"
ANALYTICS_DB = BASE_DIR / "user_data" / "analytics.json"
SECURITY_DB = BASE_DIR / "user_data" / "security.json"
BACKUPS_DIR = BASE_DIR / "user_data" / "backups"

def ensure_admin_storage():
    for d in [BASE_DIR / "user_data", BACKUPS_DIR]:
        d.mkdir(parents=True, exist_ok=True)

    env_user = os.environ.get("ADMIN_USERNAME", "admin").strip()
    env_pass = os.environ.get("ADMIN_PASSWORD", "admin123").strip()
    env_hash = hashlib.sha256(env_pass.encode()).hexdigest()

    if not ADMIN_DB.exists():
        default = {
            "admins": {
                env_user: {
                    "password_hash": env_hash,
                    "display_name": env_user.title(),
                    "role": "superadmin",
                    "created_at": int(time.time()),
                    "last_login": 0,
                    "is_active": True
                }
            },
            "sessions": {}
        }
        ADMIN_DB.write_text(json.dumps(default, indent=2), encoding="utf-8")
    else:
        data = load_json(ADMIN_DB)
        admins = data.get("admins", {})
        if env_user in admins:
            if admins[env_user].get("password_hash") != env_hash:
                admins[env_user]["password_hash"] = env_hash
                save_admin_data(data)
        else:
            data["admins"][env_user] = {
                "password_hash": env_hash,
                "display_name": env_user.title(),
                "role": "superadmin",
                "created_at": int(time.time()),
                "last_login": 0,
                "is_active": True
            }
            save_admin_data(data)
    if not SETTINGS_DB.exists():
        default_settings = {
            "site_name": "TCP Bot Panel",
            "site_logo": "",
            "favicon": "",
            "landing_text": "Premium TCP Bot Control Panel",
            "tutorial_url": "",
            "social_links": {
                "youtube": "#", "discord": "#",
                "telegram": "#", "instagram": "#"
            },
            "discord_invite": "",
            "maintenance_mode": False,
            "registration_enabled": True,
            "discord_login_enabled": True,
            "maintenance_message": "Site is under maintenance. Please try again later.",
            "announcement": "",
            "popup_notification": "",
            "dashboard_banner": "",
            "auto_bio_enabled": False,
            "auto_bio_text": "[B]╔══════════════════════╗\n  𝗧𝗛𝗜𝗦 𝗕𝗢𝗧 𝗜𝗦 𝗠𝗔𝗗𝗘 𝗕𝗬\n  𝗠𝗥 𝗞𝗔𝗟𝗣𝗛𝗔\n  mrkalpha.tech\n  Create Your Own Bot\n╚══════════════════════╝",
            "ai_prompt": "",
            "max_concurrent_bots": 50,
            "per_user_log_limit": 150,
            "rate_limit_per_minute": 30,
            "bot_memory_limit_mb": 256,
        }
        SETTINGS_DB.write_text(json.dumps(default_settings, indent=2), encoding="utf-8")
    else:
        # Migration: add missing performance settings to existing config
        data = load_json(SETTINGS_DB)
        perf_defaults = {
            "max_concurrent_bots": 50,
            "per_user_log_limit": 150,
            "rate_limit_per_minute": 30,
            "bot_memory_limit_mb": 256,
        }
        migrated = False
        for key, val in perf_defaults.items():
            if key not in data:
                data[key] = val
                migrated = True
        if migrated:
            save_json(SETTINGS_DB, data)
    if not ADMIN_LOGS_DB.exists():
        ADMIN_LOGS_DB.write_text(json.dumps([], indent=2), encoding="utf-8")
    if not ANALYTICS_DB.exists():
        default_analytics = {
            "daily": {},
            "total_friend_actions": 0,
            "total_guild_actions": 0,
            "total_api_requests": 0
        }
        ANALYTICS_DB.write_text(json.dumps(default_analytics, indent=2), encoding="utf-8")
    if not SECURITY_DB.exists():
        default_security = {
            "banned_users": [],
            "blacklisted_uids": [],
            "blocked_ips": [],
            "failed_logins": [],
            "active_sessions": {}
        }
        SECURITY_DB.write_text(json.dumps(default_security, indent=2), encoding="utf-8")


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8") or "{}")
    except (json.JSONDecodeError, FileNotFoundError):
        return {}


def save_json(path: Path, data: Any):
    path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")


def get_admin_data() -> dict:
    return load_json(ADMIN_DB)


def save_admin_data(data: dict):
    save_json(ADMIN_DB, data)


def get_settings() -> dict:
    return load_json(SETTINGS_DB)


def save_settings(data: dict):
    save_json(SETTINGS_DB, data)


def get_admin_logs() -> list:
    return load_json(ADMIN_LOGS_DB) if isinstance(load_json(ADMIN_LOGS_DB), list) else []


def save_admin_logs(logs: list):
    save_json(ADMIN_LOGS_DB, logs)


def add_admin_log(action: str, target: str = "", details: str = "", admin: str = ""):
    logs = get_admin_logs()
    logs.insert(0, {
        "action": action,
        "target": target,
        "details": details,
        "admin": admin,
        "timestamp": int(time.time())
    })
    if len(logs) > 5000:
        logs = logs[:5000]
    save_admin_logs(logs)


def get_analytics() -> dict:
    return load_json(ANALYTICS_DB)


def save_analytics(data: dict):
    save_json(ANALYTICS_DB, data)


def record_analytics_event(category: str):
    analytics = get_analytics()
    today = time.strftime("%Y-%m-%d")
    daily = analytics.setdefault("daily", {})
    day_data = daily.setdefault(today, {"registrations": 0, "active_users": 0, "bot_starts": 0, "friend_actions": 0, "guild_actions": 0, "api_requests": 0})
    if category in day_data:
        day_data[category] += 1
    elif category == "friend_actions":
        analytics["total_friend_actions"] = analytics.get("total_friend_actions", 0) + 1
    elif category == "guild_actions":
        analytics["total_guild_actions"] = analytics.get("total_guild_actions", 0) + 1
    elif category == "api_requests":
        analytics["total_api_requests"] = analytics.get("total_api_requests", 0) + 1
    cutoff = int(time.time()) - 30 * 86400
    old_keys = [k for k in daily if k < time.strftime("%Y-%m-%d", time.localtime(cutoff))]
    for k in old_keys:
        del daily[k]
    save_analytics(analytics)


def get_security() -> dict:
    return load_json(SECURITY_DB)


def save_security(data: dict):
    save_json(SECURITY_DB, data)


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def verify_admin(username: str, password: str) -> dict | None:
    data = get_admin_data()
    admin = data.get("admins", {}).get(username)
    if not admin:
        return None
    if not admin.get("is_active", True):
        return None
    if admin["password_hash"] != hash_password(password):
        failed = get_security()
        failed.setdefault("failed_logins", []).append({
            "username": username,
            "ip": "",
            "timestamp": int(time.time())
        })
        if len(failed["failed_logins"]) > 200:
            failed["failed_logins"] = failed["failed_logins"][-200:]
        save_security(failed)
        return None
    return admin


def create_admin_session(username: str) -> str:
    token = secrets.token_hex(32)
    data = get_admin_data()
    sessions = data.setdefault("sessions", {})
    sessions[token] = {
        "username": username,
        "created_at": int(time.time()),
        "ip": ""
    }
    save_admin_data(data)
    return token


def validate_admin_session(token: str) -> str | None:
    if not token:
        return None
    data = get_admin_data()
    session_info = data.get("sessions", {}).get(token)
    if not session_info:
        return None
    return session_info.get("username")


def destroy_admin_session(token: str):
    data = get_admin_data()
    data.get("sessions", {}).pop(token, None)
    save_admin_data(data)


def get_all_users() -> dict:
    from app import load_users
    return load_users()


def get_user_stats(bot_processes: dict, bot_processes_lock) -> dict:
    users = get_all_users()
    security = get_security()
    settings = get_settings()
    start_time = getattr(get_user_stats, '_start_time', time.time())
    get_user_stats._start_time = start_time

    total_users = len(users)
    banned = set(security.get("banned_users", []))
    disabled = set(security.get("disabled_logins", []))
    active_users = sum(1 for uid in users if uid not in banned and uid not in disabled)

    with bot_processes_lock:
        running_bots = sum(1 for p in bot_processes.values() if p["process"].poll() is None)
    offline_bots = total_users - running_bots

    return {
        "total_users": total_users,
        "active_users": active_users,
        "online_bots": running_bots,
        "offline_bots": max(0, offline_bots),
        "total_registered_accounts": total_users,
        "banned_users": len(banned),
        "disabled_users": len(disabled),
        "total_friend_actions": get_analytics().get("total_friend_actions", 0),
        "total_guild_actions": get_analytics().get("total_guild_actions", 0),
        "server_status": "Online" if not settings.get("maintenance_mode") else "Maintenance",
        "uptime_seconds": int(time.time() - start_time),
    }


def backup_all() -> str:
    ensure_admin_storage()
    ts = time.strftime("%Y%m%d_%H%M%S")
    backup_dir = BACKUPS_DIR / ts
    backup_dir.mkdir(parents=True, exist_ok=True)
    for src_file in [ADMIN_DB, SETTINGS_DB, ADMIN_LOGS_DB, ANALYTICS_DB, SECURITY_DB, Path(BASE_DIR / "user_data" / "users.json")]:
        if src_file.exists():
            shutil.copy2(src_file, backup_dir / src_file.name)
    return ts


def restore_backup(backup_name: str) -> bool:
    backup_dir = BACKUPS_DIR / backup_name
    if not backup_dir.exists():
        return False
    restored = False
    for f in backup_dir.iterdir():
        dest = BASE_DIR / "user_data" / f.name
        if dest.name != "runtime":
            shutil.copy2(f, dest)
            restored = True
    return restored


def list_backups() -> list:
    if not BACKUPS_DIR.exists():
        return []
    backups = []
    for d in sorted(BACKUPS_DIR.iterdir(), reverse=True):
        if d.is_dir():
            size = sum(f.stat().st_size for f in d.rglob("*") if f.is_file())
            backups.append({"name": d.name, "size": size, "files": len(list(d.iterdir()))})
    return backups


import shutil
