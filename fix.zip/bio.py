from flask import Flask, request, jsonify
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import requests
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
from emoteequip import major_login_with_retry, generate_access_token

app = Flask(__name__)

# Initialize protocol buffer definitions
_sym_db = _symbol_database.Default()

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\ndata.proto\"\xbb\x01\n\x04\x44\x61ta\x12\x0f\n\x07\x66ield_2\x18\x02 \x01(\x05\x12\x1e\n\x07\x66ield_5\x18\x05 \x01(\x0b\x32\r.EmptyMessage\x12\x1e\n\x07\x66ield_6\x18\x06 \x01(\x0b\x32\r.EmptyMessage\x12\x0f\n\x07\x66ield_8\x18\x08 \x01(\t\x12\x0f\n\x07\x66ield_9\x18\t \x01(\x05\x12\x1f\n\x08\x66ield_11\x18\x0b \x01(\x0b\x32\r.EmptyMessage\x12\x1f\n\x08\x66ield_12\x18\x0c \x01(\x0b\x32\r.EmptyMessage\"\x0e\n\x0c\x45mptyMessageb\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'data_pb2', _globals)

if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR._options = None
    _globals['_DATA']._serialized_start = 15
    _globals['_DATA']._serialized_end = 202
    _globals['_EMPTYMESSAGE']._serialized_start = 204
    _globals['_EMPTYMESSAGE']._serialized_end = 218

Data = _sym_db.GetSymbol('Data')
EmptyMessage = _sym_db.GetSymbol('EmptyMessage')

# Constants
KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
IV = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

# Region URLs
REGION_URLS = {
    "IND": "https://client.ind.freefiremobile.com/UpdateSocialBasicInfo",
    "ID": "https://clientbp.ggblueshark.com/UpdateSocialBasicInfo",
    "BR": "https://client.us.freefiremobile.com/UpdateSocialBasicInfo",
    "ME": "https://clientbp.common.ggbluefox.com/UpdateSocialBasicInfo",
    "VN": "https://clientbp.ggblueshark.com/UpdateSocialBasicInfo",
    "TH": "https://clientbp.common.ggbluefox.com/UpdateSocialBasicInfo",
    "CIS": "https://clientbp.common.ggbluefox.com/UpdateSocialBasicInfo",
    "BD": "https://clientbp.ggpolarbear.com/UpdateSocialBasicInfo",
    "PK": "https://clientbp.ggblueshark.com/UpdateSocialBasicInfo",
    "SG": "https://clientbp.ggblueshark.com/UpdateSocialBasicInfo",
    "NA": "https://client.us.freefiremobile.com/UpdateSocialBasicInfo",
    "SAC": "https://client.us.freefiremobile.com/UpdateSocialBasicInfo",
    "EU": "https://clientbp.ggblueshark.com/UpdateSocialBasicInfo",
    "TW": "https://clientbp.ggblueshark.com/UpdateSocialBasicInfo"
}

def get_jwt_token(auth_method, auth_data):
    """Get JWT token using local MajorLogin (no external API)"""
    try:
        if auth_method == 'access_token':
            if not auth_data.get('access_token'):
                raise ValueError("Authentication failed")
            open_id = auth_data.get('open_id')
            if not open_id:
                raise ValueError("open_id required for access_token auth")
            result = major_login_with_retry(open_id, auth_data['access_token'])
        elif auth_method == 'uid_password':
            if not auth_data.get('uid') or not auth_data.get('password'):
                raise ValueError("Authentication failed")
            open_id, access_token, err = generate_access_token(auth_data['uid'], auth_data['password'])
            if not open_id or not access_token:
                raise ValueError("Failed to generate access token")
            result = major_login_with_retry(open_id, access_token)
        else:
            raise ValueError("Invalid auth method")

        if not result or not result.get('token'):
            raise ValueError("MajorLogin failed")

        return result['token']
    except Exception as e:
        raise ValueError(str(e) if str(e) else "Authentication failed")

@app.route('/bio_change', methods=['GET'])
def bio_change():
    try:
        # Get query parameters
        bio = request.args.get('bio')
        region = request.args.get('region', 'IND').upper()
        access_token = request.args.get('access_token')
        open_id = request.args.get('open_id')
        uid = request.args.get('uid')
        password = request.args.get('password')
        
        # Validate required parameters
        if not bio:
            return jsonify({
                "status": False,
                "message": "Bio is required",
                "error_code": 400
            }), 400
        
        if len(bio) >= 1800:
            return jsonify({
                "status": False,
                "message": "Bio must be less than 1800 characters",
                "error_code": 400
            }), 400
        
        # Validate region selection
        if region not in REGION_URLS:
            return jsonify({
                "status": False,
                "message": f"Invalid region. Available: {', '.join(REGION_URLS.keys())}",
                "error_code": 400
            }), 400
        
        # Get authentication token
        try:
            if access_token and open_id:
                token = get_jwt_token('access_token', {'access_token': access_token, 'open_id': open_id})
                auth_method = "access_token"
            elif uid and password:
                token = get_jwt_token('uid_password', {'uid': uid, 'password': password})
                auth_method = "uid_password"
            else:
                return jsonify({
                    "status": False,
                    "message": "Provide either access_token+open_id or uid+password",
                    "error_code": 400
                }), 400
        except ValueError as e:
            return jsonify({
                "status": False,
                "message": str(e),
                "error_code": 401
            }), 401
        
        # Create and serialize protocol buffer message
        pb_data = Data()
        pb_data.field_2 = 17
        pb_data.field_5.CopyFrom(EmptyMessage())
        pb_data.field_6.CopyFrom(EmptyMessage())
        pb_data.field_8 = bio
        pb_data.field_9 = 1
        pb_data.field_11.CopyFrom(EmptyMessage())
        pb_data.field_12.CopyFrom(EmptyMessage())
        
        data_bytes = pb_data.SerializeToString()
        padded_data = pad(data_bytes, AES.block_size)
        
        # Encrypt data
        cipher = AES.new(KEY, AES.MODE_CBC, IV)
        encrypted_data = cipher.encrypt(padded_data)
        data_hex = ''.join([f"{byte:02X}" for byte in encrypted_data])
        data_bytes = bytes.fromhex(data_hex)
        
        # Prepare headers
        url = REGION_URLS[region]
        headers = {
            "Expect": "100-continue",
            "Authorization": f"Bearer {token}",
            "X-Unity-Version": "2018.4.11f1",
            "X-GA": "v1 1",
            "ReleaseVersion": "OB54",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 11; SM-A305F Build/RP1A.200720.012)",
            "Host": url.split('/')[2],
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip"
        }
        
        # Make request to Free Fire server
        response = requests.post(url, headers=headers, data=data_bytes, timeout=10)
        
        if response.status_code != 200:
            return jsonify({
                "status": False,
                "message": "Failed to update bio",
                "error_code": response.status_code,
                "region": region
            }), response.status_code
        
        return jsonify({
            "status": True,
            "message": "Bio updated successfully",
            "region": region,
            "bio": bio
        })
        
    except Exception as e:
        return jsonify({
            "status": False,
            "message": "An error occurred",
            "error_code": 500,
            "details": str(e)
        }), 500

@app.route('/')
def index():
    return jsonify({
        "status": True,
        "message": "Free Fire Bio Change API",
        "endpoint": "/bio_change",
        "parameters": {
            "bio": "Your new bio text (required)",
            "region": f"Server region (default: IND). Available: {', '.join(REGION_URLS.keys())}",
            "authentication": "Either access_token+open_id OR uid+password (required)"
        },
        "example_requests": [
            "/bio_change?bio=HelloWorld&region=BR&access_token=YOUR_TOKEN&open_id=YOUR_OPEN_ID",
            "/bio_change?bio=NewBio&region=BD&uid=12345&password=BrokenPlayz"
        ]
    })

if __name__ == '__main__':
    app.run(debug=True)
