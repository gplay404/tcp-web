async def send_free_gift(uid: str) -> str:
    url = "https://freefirejornal.com/codiguin-ff-pelo-id/"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, ssl=False) as resp:
                if resp.status != 200:
                    return f"[B][C][FF0000]❌ Website reach nahi ho paaya (HTTP {resp.status})"
                html = await resp.text()

            soup = BeautifulSoup(html, 'html.parser')
            form = soup.find('form')
            if not form:
                return "[B][C][FF0000]❌ Form nahi mila website par. Shayad site change ho gayi."

            action = form.get('action', url)
            method = form.get('method', 'post').lower()

            inputs = form.find_all('input')
            data = {}
            uid_field = None

            for inp in inputs:
                name = inp.get('name')
                value = inp.get('value', '')
                if name:
                    data[name] = value
                    if name.lower() in ('uid', 'playerid', 'player_id', 'id'):
                        uid_field = name

            if not uid_field and inputs:
                for inp in inputs:
                    if inp.get('name'):
                        uid_field = inp.get('name')
                        break

            if not uid_field:
                return "[B][C][FF0000]❌ Form me UID daalne wala field nahi mila."

            data[uid_field] = uid

            if method == 'post':
                async with session.post(action, data=data, ssl=False) as resp2:
                    if resp2.status == 200:
                        return f"[B][C][00FF00]✅ Gift ({uid}) successfully sent! 🎁"
                    else:
                        return f"[B][C][FF0000]❌ Submit fail (HTTP {resp2.status})"
            else:
                async with session.get(action, params=data, ssl=False) as resp2:
                    if resp2.status == 200:
                        return f"[B][C][00FF00]✅ Gift ({uid}) successfully sent! 🎁"
                    else:
                        return f"[B][C][FF0000]❌ Submit fail (HTTP {resp2.status})"

    except Exception as e:
        return f"[B][C][FF0000]❌ Error: {str(e)}"
        
        
                        elif inPuTMsG.strip().startswith('/sendfreegift '):
                            print('Processing sendfreegift command')
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = (
            "[B][C][FF0000]⛔ COMMAND REJECTED\n"
            "[B][C][FFFFFF]Usage: /sendfreegift <uid>\n"
            "[B][C][AAAAAA]Example: /sendfreegift 1234567890"
                                )
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                continue

                            target_uid = parts[1]
                            if not target_uid.isdigit() or len(target_uid) < 8:
                                await safe_send_message(
                                    response.Data.chat_type,
                                    "[B][C][FF0000]❌ Invalid UID! Must be 8+ digits.",
                                    uid, chat_id, key, iv
                                )
                                continue

                            await safe_send_message(
                                response.Data.chat_type,
                                f"[B][C][FFFF00]⏳ Sending free gift to {fixnum(target_uid)}...",
                                uid, chat_id, key, iv
                            )

                            result = await send_free_gift(target_uid)
                            await safe_send_message(response.Data.chat_type, result, uid, chat_id, key, iv)
